"""Two independently launchable FastAPI applications with a PostgreSQL journal."""
from __future__ import annotations

import hmac
import logging
import threading
from contextlib import asynccontextmanager

import psycopg
from fastapi import FastAPI, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.exceptions import RequestValidationError
from starlette.datastructures import UploadFile
from starlette.exceptions import HTTPException
from starlette.responses import JSONResponse

from . import __version__
from . import deterministic, vlm
from .contracts import LIMITS, digest, parse_metadata, result_envelope, structural, validate_request, validate_result
from .errors import AnalysisError
from .equipment_activity import EXTENSION, RULE_VERSION, assess
from .gateway import Gateway
from .settings import Settings
from .storage import Storage
from .resource_plan import LIMITS as RESOURCE_LIMITS, RULE_VERSION as RESOURCE_RULE_VERSION
from .work_progress import RULE_VERSION as PROGRESS_RULE_VERSION, summarize


class BodyLimit:
    """Bound multipart parsing before large uploads reach disk or decoding."""
    def __init__(self, app, service):
        self.app, self.service = app, service

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope["method"] != "POST":
            await self.app(scope, receive, send)
            return
        size = 0
        limit = LIMITS["image_max_bytes"] + LIMITS["metadata_max_bytes"] + 100_000
        async def bounded():
            nonlocal size
            message = await receive()
            size += len(message.get("body", b""))
            if size > limit:
                raise AnalysisError("payload_too_large", "Multipart request exceeds the byte limit", 413)
            return message
        await self.app(scope, bounded, send)


def create_app(service, settings=None):
    if service not in {"deterministic", "vlm_llm"}:
        raise ValueError("Unknown analytics service")
    config = settings or Settings.from_env()
    config.check()
    storage = Storage(config, service)
    gate = threading.BoundedSemaphore(config.max_concurrency)

    @asynccontextmanager
    async def lifespan(app):
        # Start even without references/gateway: live and ready must differ.
        yield

    app = FastAPI(title="Construction analytics: " + service, version=__version__, lifespan=lifespan,
                  docs_url=None, redoc_url=None)
    app.add_middleware(BodyLimit, service=service)
    app.state.storage, app.state.settings = storage, config

    def request_version(request):
        return 2 if request.url.path.startswith("/v2/") else 1

    def error_response(error, request_id=None, *, version=1):
        body = error.response(service, request_id, version=version)
        headers = {"Retry-After": "2"} if error.code == "busy" else None
        return JSONResponse(body, status_code=error.status, headers=headers)

    @app.exception_handler(AnalysisError)
    async def analytics_error(request, exc):
        return error_response(exc, getattr(request.state, "request_id", None), version=request_version(request))

    @app.exception_handler(HTTPException)
    async def request_error(request, exc):
        return error_response(AnalysisError("invalid_request", "HTTP request could not be parsed", 400),
                              getattr(request.state, "request_id", None), version=request_version(request))

    @app.exception_handler(RequestValidationError)
    async def parameter_error(request, exc):
        return error_response(AnalysisError("invalid_request", "Required HTTP parameters are missing or invalid", 400),
                              getattr(request.state, "request_id", None), version=request_version(request))

    @app.exception_handler(Exception)
    async def internal_error(request, exc):
        return error_response(AnalysisError("internal_error", "Internal service failure", 500, execution_state="unknown"),
                              getattr(request.state, "request_id", None), version=request_version(request))

    def authenticate(request):
        if not config.service_token:
            raise AnalysisError("not_ready", "Service credential is not configured", 503, retryable=True)
        token = request.headers.get("authorization", "")
        if not token.startswith("Bearer ") or not hmac.compare_digest(token[7:].encode(), config.service_token.encode()):
            raise AnalysisError("unauthorized", "A valid service credential is required", 401)

    def references():
        try:
            return storage.references()
        except psycopg.Error:
            raise AnalysisError("dependency_unavailable", "PostgreSQL references are unavailable", 503, retryable=True) from None

    @app.get("/health/live")
    def live():
        return {"status": "alive"}

    @app.get("/health/ready")
    def ready():
        if not config.service_token or (service == "vlm_llm" and not config.gateway_key):
            return error_response(AnalysisError("not_ready", "Required service configuration is missing", 503, retryable=True))
        try:
            references()
            with storage.connection() as connection:
                connection.execute("SELECT input_version FROM analytics_runtime.request LIMIT 1")
                connection.execute("SELECT 1 FROM analytics_runtime.resource_plan_snapshot LIMIT 1")
                connection.execute("SELECT 1 FROM analytics_runtime.source_snapshot LIMIT 1")
        except AnalysisError as exc:
            return error_response(exc)
        except psycopg.Error:
            return error_response(AnalysisError("dependency_unavailable", "Request journal is unavailable", 503, retryable=True))
        return {"status": "ready", "service": service, "service_version": __version__}

    @app.get("/v1/catalog")
    def catalog(request: Request):
        authenticate(request)
        value = references().catalog()
        structural(value, "catalog")
        return value

    @app.get("/v1/capabilities")
    def capabilities(request: Request, include_extensions: bool = False):
        authenticate(request)
        value = {"schema_version": "frame-analysis-capabilities-v1", "service": service,
                 "service_version": __version__, "input_version": "frame-analysis-input-v1",
                 "result_version": "frame-analysis-result-v1", "catalog_version": references().catalog_version,
                 "limits": LIMITS}
        if include_extensions:
            value["extensions"] = [EXTENSION]
        structural(value, "capabilities")
        return value

    @app.get("/v2/capabilities")
    def capabilities_v2(request: Request):
        authenticate(request)
        value = {"schema_version": "frame-analysis-capabilities-v2", "service": service,
                 "service_version": __version__, "input_version": "frame-analysis-input-v2",
                 "result_version": "frame-analysis-result-v2", "catalog_version": references().catalog_version,
                 "limits": {**LIMITS, **RESOURCE_LIMITS}, "extensions": [EXTENSION],
                 "resource_rules_version": RESOURCE_RULE_VERSION if service == "deterministic" else None,
                 "analysis_modes": ["demonstration", "operational"]}
        structural(value, "capabilities")
        return value

    def existing(claim):
        if claim.get("busy"):
            raise AnalysisError("busy", "This request is already executing", 429, retryable=True)
        if claim.get("unknown"):
            raise AnalysisError("execution_uncertain", "Execution state is uncertain; no automatic model retry", 409, execution_state="unknown")
        return JSONResponse(claim["response"], status_code=claim["status"])

    @app.get("/v1/analyses/by-request/{request_id}")
    @app.get("/v2/analyses/by-request/{request_id}")
    def lookup(request_id: str, site_id: str, request: Request):
        authenticate(request)
        request.state.request_id = request_id if 0 < len(request_id) <= 100 else None
        if not request.state.request_id or not 0 < len(site_id) <= 100:
            raise AnalysisError("invalid_request", "Invalid request/site identifier", 400)
        try:
            return existing(storage.lookup(site_id, request_id,
                            input_version="frame-analysis-input-v" + str(request_version(request))))
        except psycopg.Error:
            raise AnalysisError("dependency_unavailable", "Request journal is unavailable", 503, retryable=True) from None

    def process(case, raw_metadata, image, media_type, version):
        structural(case, "request", version=version)
        fingerprint = digest(raw_metadata + b"\x00" + image)
        # A durable outcome remains available after reference/configuration changes.
        try:
            prior = storage.lookup(case["site_id"], case["request_id"], fingerprint=fingerprint)
        except AnalysisError as exc:
            if exc.code != "analysis_not_found":
                raise
        except psycopg.Error:
            raise AnalysisError("dependency_unavailable", "Request journal is unavailable", 503, retryable=True) from None
        else:
            return existing(prior)
        refs = references()
        versions = result_envelope(case, service, "pending", fingerprint, refs)["versions"]
        if "equipment_activity" in case:
            versions["equipment_activity_rules_version"] = RULE_VERSION
            versions["work_progress_rules_version"] = PROGRESS_RULE_VERSION
        needs_model = service == "vlm_llm" and case["scope"]["plan_stream_code"] is not None and bool(vlm.visual_step_keys(case, refs))
        if service == "vlm_llm":
            versions.update(vision_model=config.model, llm_model=config.model)
        if not gate.acquire(blocking=False):
            raise AnalysisError("busy", "Service concurrency limit reached", 429, retryable=True)
        claimed = False
        gateway_started = False
        try:
            # Bound full image decoding as well as the expensive model operation.
            validate_request(case, image, refs, media_type)
            if needs_model and not config.gateway_key:
                raise AnalysisError("not_ready", "Gateway credential is not configured", 503, retryable=True)
            claim = storage.claim(case, raw_metadata, image, fingerprint, versions)
            if not claim["new"]:
                return existing(claim)
            claimed = True
            def save(phase, payload):
                nonlocal gateway_started
                if phase.endswith("_start"):
                    # Set the in-process marker before the write; a failing write prevents the network call.
                    gateway_started = True
                storage.attempt(case, phase, payload)
            activity = (assess(case, result_envelope(case, service, claim["analysis_id"], fingerprint, refs))
                        if "equipment_activity" in case else None)
            if service == "deterministic":
                result = deterministic.analyze(case, refs, claim["analysis_id"], fingerprint, equipment_activity=activity)
            else:
                gateway = Gateway(config.gateway_url, config.gateway_key, config.model, config.model_timeout)
                result = vlm.analyze(case, image, refs, gateway, claim["analysis_id"], fingerprint, save, equipment_activity=activity)
            if "equipment_activity" in case:
                result["equipment_activity"] = assess(case, result)
                result["versions"]["equipment_activity_rules_version"] = RULE_VERSION
                result["work_progress"] = summarize(case, result, refs)
                result["versions"]["work_progress_rules_version"] = PROGRESS_RULE_VERSION
            validate_result(result, case, refs)
            storage.finish(case, result, 200)
            return JSONResponse(result)
        except AnalysisError as exc:
            if claimed:
                storage.finish(case, exc.response(service, case["request_id"], version=version), exc.status,
                               unknown=exc.execution_state == "unknown")
            raise
        except (psycopg.Error, OSError):
            error = AnalysisError("dependency_unavailable", "Analysis persistence failed", 503,
                                  execution_state="unknown" if gateway_started else "failed")
            if claimed:
                try:
                    storage.finish(case, error.response(service, case["request_id"], version=version), 503, unknown=gateway_started)
                except psycopg.Error:
                    # The durable running marker survives; stale lookup converts it to unknown.
                    logging.getLogger(__name__).error("PostgreSQL journal update failed")
            raise error from None
        except Exception:
            error = AnalysisError("internal_error", "Analysis failed internally", 500,
                                  execution_state="unknown" if gateway_started else "failed")
            if claimed:
                try:
                    storage.finish(case, error.response(service, case["request_id"], version=version), 500, unknown=gateway_started)
                except psycopg.Error:
                    logging.getLogger(__name__).error("PostgreSQL journal update failed")
            raise error from None
        finally:
            gate.release()

    @app.post("/v1/analyze/frame")
    @app.post("/v2/analyze/frame")
    async def analyze(request: Request):
        authenticate(request)
        if not request.headers.get("content-type", "").lower().startswith("multipart/form-data"):
            raise AnalysisError("unsupported_media_type", "Multipart metadata and image parts are required", 415)
        async with request.form(max_files=2, max_fields=2, max_part_size=LIMITS["metadata_max_bytes"]) as form:
            parts = form.multi_items()
            if len(parts) != 2 or {k for k, _ in parts} != {"metadata", "image"}:
                raise AnalysisError("invalid_request", "Exactly one metadata and one image part are required", 400)
            metadata, picture = form["metadata"], form["image"]
            if not isinstance(metadata, UploadFile) or not isinstance(picture, UploadFile):
                raise AnalysisError("invalid_request", "Parts require explicit application/json and image Content-Type", 400)
            if (metadata.content_type or "").split(";", 1)[0].lower() != "application/json":
                raise AnalysisError("unsupported_media_type", "Metadata must be application/json", 415)
            raw_metadata = await metadata.read(LIMITS["metadata_max_bytes"] + 1)
            image = await picture.read(LIMITS["image_max_bytes"] + 1)
            case = parse_metadata(raw_metadata)
            value = case.get("request_id") if isinstance(case, dict) else None
            request.state.request_id = value if isinstance(value, str) and 0 < len(value) <= 100 else None
            if request.headers.get("idempotency-key") != request.state.request_id or request.state.request_id is None:
                raise AnalysisError("invalid_request", "Idempotency-Key must equal the metadata request_id", 400)
            return await run_in_threadpool(process, case, raw_metadata, image, picture.content_type, request_version(request))

    return app


def deterministic_app():
    return create_app("deterministic")


def vlm_app():
    return create_app("vlm_llm")
