"""JSON Schema guidance for the existing construction-context-v1 contract.

The local semantic validator remains authoritative for cross-field rules and
evidence references. This schema only constrains what the gateway can decode.
"""
from __future__ import annotations

from .vision_contract import ACTIVITIES, CHECK_TARGETS, LABELS, SCHEMA_VERSION


def obj(properties: dict) -> dict:
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


def string(max_length: int) -> dict:
    return {"type": "string", "maxLength": max_length}


def enum(values: set[str] | tuple[str, ...]) -> dict:
    return {"type": "string", "enum": sorted(values)}


def array(items: dict, max_items: int, min_items: int = 0) -> dict:
    return {"type": "array", "items": items, "minItems": min_items,
            "maxItems": max_items}


def response_format() -> dict:
    bbox = array({"type": "number", "minimum": 0, "maximum": 1}, 4, 4)
    observation_fields = {
        "id": string(20),
        "description": string(300),
        "state": enum(("installed", "stockpiled", "assembled", "scattered", "unknown", "not_applicable")),
        "certainty": enum(("high", "medium", "low")),
        "bbox": bbox,
        "visible_count": {"anyOf": [{"type": "integer", "minimum": 1}, {"type": "null"}]},
    }
    observation = {"oneOf": [
        obj({"id": observation_fields["id"],
             "category": {"type": "string", "const": category},
             "label": enum(labels),
             **{key: value for key, value in observation_fields.items() if key != "id"}})
        for category, labels in LABELS.items()
    ]}
    relation = obj({
        "id": string(20), "subject_id": string(20),
        "predicate": enum(("inside", "on", "adjacent_to")),
        "object_id": string(20),
        "certainty": enum(("high", "medium", "low")),
        "description": string(300),
    })
    check = obj({
        "target": enum(CHECK_TARGETS),
        "result": enum(("present", "uncertain", "not_observed", "not_assessable")),
        "evidence_ids": array(string(20), 30),
        "reason": string(300),
    })
    hypothesis = obj({
        "activity_code": enum(ACTIVITIES),
        "support": enum(("strong", "moderate", "weak")),
        "evidence_ids": array(string(20), 50, 1),
        "explanation": string(400),
        "uncertainty": string(300),
    })
    schema = obj({
        "schema_version": {"type": "string", "const": SCHEMA_VERSION},
        "image_id": string(100),
        "status": enum(("ok", "partial", "unassessable")),
        "scene_summary": string(500),
        "image_quality": obj({
            "view": enum(("outdoor", "indoor", "mixed", "unknown")),
            "detail": enum(("adequate", "limited", "insufficient")),
            "occlusion": enum(("low", "medium", "high", "unknown")),
            "issues": array(enum(("blur", "darkness", "glare", "low_resolution", "distant_objects", "occlusion", "cropped_scene", "other")), 8),
        }),
        "observations": array(observation, 30),
        "relations": array(relation, 20),
        "checks": array(check, 8, 8),
        "activity_hypotheses": array(hypothesis, 3),
        "limitations": array(string(300), 8),
    })
    return {"type": "json_schema", "json_schema": {
        "name": "construction_context_v1", "strict": True, "schema": schema,
    }}
