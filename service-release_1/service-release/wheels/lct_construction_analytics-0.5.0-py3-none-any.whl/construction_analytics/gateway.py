"""Real OpenAI-compatible HTTP transport with explicit uncertain execution."""
from __future__ import annotations

import base64
import json
import ssl
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

from jsonschema import Draft202012Validator

from .errors import AnalysisError
from .vision_contract import parse_model_content, validate_payload
from .vision_schema import response_format


class Gateway:
    def __init__(self, url, key, model, timeout=240):
        self.url, self.key, self.model, self.timeout = url, key, model, timeout

    def completion(self, messages, schema):
        if not self.key:
            raise AnalysisError("not_ready", "Gateway credential is not configured", 503, retryable=True)
        body = {"model": self.model, "messages": messages, "temperature": 0,
                "max_tokens": 4000, "response_format": schema}
        if self.model.startswith("qwen3.8"):
            body["chat_template_kwargs"] = {"enable_thinking": False}
        request = urllib.request.Request(self.url.rstrip("/") + "/chat/completions",
                                         data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
                                         headers={"Authorization": "Bearer " + self.key, "Content-Type": "application/json"},
                                         method="POST")
        start = time.monotonic()
        started_at = datetime.now(timezone.utc).isoformat()
        try:
            with urllib.request.urlopen(request, timeout=self.timeout, context=ssl.create_default_context()) as response:
                status, raw = response.status, response.read(4_000_001)
        except urllib.error.HTTPError as exc:
            uncertain = exc.code >= 500
            raise AnalysisError("model_failure", "Gateway returned an HTTP error", 502,
                                execution_state="unknown" if uncertain else "failed") from None
        except (OSError, TimeoutError):
            raise AnalysisError("analysis_timeout", "Gateway response was not received; execution is uncertain", 504,
                                execution_state="unknown") from None
        if len(raw) > 4_000_000:
            raise AnalysisError("model_invalid_response", "Gateway response exceeds the limit", 502, execution_state="failed")
        try:
            reply = json.loads(raw)
        except (ValueError, UnicodeError):
            reply = None
        choices = reply.get("choices") if isinstance(reply, dict) else None
        message = choices[0].get("message") if isinstance(choices, list) and choices and isinstance(choices[0], dict) else None
        content = message.get("content") if isinstance(message, dict) else None
        payload, parse_error, strict = parse_model_content(content)
        record = {"started_at": started_at, "model": self.model,
                  "response_model": reply.get("model") if isinstance(reply, dict) else None,
                  "http_status": status, "transport_error": None,
                  "latency_seconds": round(time.monotonic() - start, 6),
                  "usage": reply.get("usage") if isinstance(reply, dict) else None,
                  "raw_content": content, "payload": payload, "strict_json": strict,
                  "parse_error": parse_error}
        # Keys never enter prompts; redact accidental echoes before audit persistence.
        escaped_key = json.dumps(self.key, ensure_ascii=False)[1:-1]
        def redact(value):
            if isinstance(value, str):
                return value.replace(escaped_key, "<redacted>").replace(self.key, "<redacted>")
            if isinstance(value, list):
                return [redact(item) for item in value]
            if isinstance(value, dict):
                return {redact(key): redact(item) for key, item in value.items()}
            return value
        return redact(record)

    def image(self, data, mime, image_id, image_sha, prompt):
        messages = [{"role": "system", "content": prompt}, {"role": "user", "content": [
            {"type": "text", "text": "Проанализируй кадр. image_id: " + json.dumps(image_id, ensure_ascii=False)},
            {"type": "image_url", "image_url": {"url": "data:" + mime + ";base64," + base64.b64encode(data).decode("ascii")}}]}]
        schema = response_format()
        record = self.completion(messages, schema)
        payload = record["payload"]
        structural = list(Draft202012Validator(schema["json_schema"]["schema"]).iter_errors(payload))
        errors = ["vision_schema:" + str(e.validator) for e in structural[:20]]
        if not structural:
            errors.extend(validate_payload(payload, image_id))
        record.update(image_id=image_id, image_sha256=image_sha, validation_errors=errors,
                      schema_valid=record["strict_json"] and not errors and record["http_status"] == 200)
        return record

    def text(self, prompt, schema, system):
        return self.completion([{"role": "system", "content": system}, {"role": "user", "content": prompt}], schema)
