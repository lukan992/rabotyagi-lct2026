"""Qualitative plan signals; machine motion never supplies a completed volume."""
from __future__ import annotations

from .deterministic import latest_progress
from .equipment_activity import ignored_idle_refs
from .errors import AnalysisError

RULE_VERSION = "equipment-work-progress-v1"


def summarize(case, result, references):
    assessment = result["equipment_activity"]
    excluded = sorted(ignored_idle_refs(case, assessment))
    value = {"schema_version": "work-progress-result-v1", "rules_version": RULE_VERSION,
             "status": "insufficient_evidence", "summary": "",
             "total_plan_steps": 0, "confirmed_completed_steps": 0,
             "next_stage_status": result["transition"]["status"],
             "excluded_detection_refs": excluded, "steps": [], "limitations": [
                 "Движение техники совместимо с работой, но не доказывает выполнение конкретного пункта или объём.",
                 "possible_inactivity — подозрение на неактивность совместимой техники, а не подтверждённая остановка работы.",
                 "Подтверждённый ход берётся только из sourced progress; объём и процент готовности по bbox не вычисляются.",
                 "Одна машина может подходить нескольким пунктам; сигналы не означают несколько одновременно выполняемых работ.",
             ]}
    if case["scope"]["plan_stream_code"] is None:
        value.update(status="scope_unknown", summary="Нет подтверждённой привязки камеры к участку плана; ход работ не сопоставлен.")
        return value
    if case["plan"] is None:
        value.update(status="no_plan", summary="План не передан; активность техники не сопоставлена с ходом работ.")
        return value
    assertions = latest_progress(case)
    stage_classes = {}
    for pair in references.matrix["pairs"]:
        if pair["kind"] == "equipment" and pair["role_weight"] > 0:
            stage_classes.setdefault(pair["stage_id"], set()).add(pair["class_code"])
    for step in sorted(case["plan"]["steps"], key=lambda s: s["sequence_no"]):
        key, stage = step["step_key"], references.stages[step["stage_id"]]
        assertion = assertions.get(key)
        groups = [(i, g) for i, g in enumerate(result["current_work"]["work_groups"])
                  if any(c["step_key"] == key for c in g["candidates"])]
        related = [(i, item) for i, item in enumerate(assessment["items"])
                   if item["class_code"] in stage_classes.get(step["stage_id"], set())]
        if case["object_type_code"] is not None and case["object_type_code"] not in stage["object_type_codes"]:
            related = []
        # Localized VLM groups attribute only machines explicitly supporting them.
        if result["service"] == "vlm_llm" and groups:
            linked = {e["ref"] for _, group in groups for e in group["evidence"]
                      if e["source"] == "cv_detection" and e["role"] == "supports"}
            related = [(i, item) for i, item in related if f"/cv/detections/{i}" in linked]
        if stage["stage_kind"] == "no_class":
            related = []
        operations = [f"/current_work/work_groups/{i}" for i, g in groups
                      if g["visual_state"] == "operation_indicated"]
        supporting = [f"/cv/detections/{i}" for i, item in related
                      if item["status"] == "movement_indicated" or (item["status"] == "operation_indicated" and operations)]
        idle = [f"/cv/detections/{i}" for i, item in related if item["status"] == "possible_idle"]
        uncertain = [f"/cv/detections/{i}" for i, item in related
                     if f"/cv/detections/{i}" not in supporting and f"/cv/detections/{i}" not in idle]
        if groups:
            match = "ambiguous" if any(g["match_status"] == "ambiguous" for _, g in groups) else "specific"
        else:
            match = "compatibility_only" if related else "not_selected"
        reasons = []
        if stage["stage_kind"] == "no_class":
            status, explanation = "not_visual", "Этот пункт не оценивается по технике; требуется внешний источник хода работ."
        elif operations:
            status, explanation = "operation_indicated", "В связанной визуальной группе есть признаки операции; выполнение пункта этим не подтверждено."
        elif supporting:
            status, explanation = "equipment_movement_indicated", "Есть движение техники, совместимой с работой; движение или переезд не подтверждает выполнение пункта."
        elif idle and not uncertain:
            status, explanation = "possible_inactivity", "Все сопоставленные с пунктом видимые машины имеют possible_idle; они не поддерживают вывод об активности работы."
        elif related or groups:
            status, explanation = "presence_only", "Есть совместимая техника или визуальные признаки присутствия/результата; активность работы не установлена."
        else:
            status, explanation = "insufficient_evidence", "Надёжных признаков активности этого пункта на текущем кадре недостаточно; отсутствие работ не установлено."
        reasons.append(status)
        if idle:
            reasons.append("idle_equipment_excluded")
        if match in {"ambiguous", "compatibility_only"}:
            reasons.append("exact_work_not_established")
        if assertion and assertion[1]["state"] == "completed" and (operations or supporting):
            reasons.append("activity_after_sourced_completion")
            explanation += " Пункт ранее отмечен завершённым; соответствие текущих признаков этому пункту требует проверки."
        value["steps"].append({"step_key": key, "stage_id": step["stage_id"],
                               "confirmed_state": assertion[1]["state"] if assertion else "unknown",
                               "confirmed_at": assertion[1]["effective_at"] if assertion else None,
                               "progress_evidence_refs": [assertion[2]] if assertion else [],
                               "activity_status": status, "candidate_match_status": match,
                               "supporting_detection_refs": supporting, "ignored_idle_detection_refs": idle,
                               "uncertain_detection_refs": uncertain,
                               "activity_evidence_refs": [f"/equipment_activity/items/{i}" for i, _ in related],
                               "visual_activity_refs": operations, "reason_codes": reasons,
                               "explanation": explanation})
    items = value["steps"]
    value["total_plan_steps"] = len(items)
    value["confirmed_completed_steps"] = sum(item["confirmed_state"] == "completed" for item in items)
    statuses = {item["activity_status"] for item in items}
    value["status"] = "assessed" if assertions or statuses - {"insufficient_evidence", "not_visual"} else "insufficient_evidence"
    counts = {state: sum(item["activity_status"] == state for item in items)
              for state in ("operation_indicated", "equipment_movement_indicated", "possible_inactivity", "presence_only")}
    value["summary"] = (f"В переданных источниках подтверждено завершение {value['confirmed_completed_steps']} из {len(items)} пунктов. "
                        f"Кандидаты по текущему кадру: признаки операции — {counts['operation_indicated']}, "
                        f"движение совместимой техники — {counts['equipment_movement_indicated']}, "
                        f"подозрение на неактивность техники — {counts['possible_inactivity']}, "
                        f"только присутствие/результат — {counts['presence_only']}. "
                        "Это качественные сигналы; выполненный объём и процент готовности не определены.")
    if result["transition"]["status"] == "possible_start":
        value["summary"] += " Есть сигнал возможного начала следующей работы, не подтверждённый переход."
    return value


def validate_summary(case, result, references):
    enabled = "equipment_activity" in case
    if ("work_progress" in result) != enabled:
        raise AnalysisError("internal_error", "Work progress extension presence disagrees with its request", 500)
    if not enabled:
        return
    if result["versions"].get("work_progress_rules_version") != RULE_VERSION:
        raise AnalysisError("internal_error", "Work progress rule version is missing", 500)
    if references is not None and result["work_progress"] != summarize(case, result, references):
        raise AnalysisError("internal_error", "Work progress does not match its sourced plan/activity evidence", 500)
