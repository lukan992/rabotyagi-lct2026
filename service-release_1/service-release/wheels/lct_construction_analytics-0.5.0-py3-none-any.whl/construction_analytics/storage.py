"""PostgreSQL reference reader and durable, atomic request/identity journal."""
from __future__ import annotations

import json
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from uuid import uuid4

import psycopg
from psycopg import sql
from psycopg.rows import dict_row
from psycopg.types.json import Jsonb

from .contracts import canonical, digest, moment
from .errors import AnalysisError

ROLES = {"deterministic": "lct_analytics_deterministic", "vlm_llm": "lct_analytics_vlm"}


@dataclass
class References:
    matrix: dict
    catalog_version: str
    profiles_version: str
    profiles: dict
    source_snapshot: dict
    metadata: dict

    @property
    def stages(self):
        return {s["id"]: s for s in self.matrix["stages"]}

    @property
    def equipment_codes(self):
        return {c["code"] for c in self.matrix["classes"] if c["kind"] == "equipment"}

    def catalog(self):
        aliases = self.matrix["aliases"]
        return {"schema_version": "frame-analysis-catalog-v1", "catalog_version": self.catalog_version,
                "equipment_classes": [{"code": c["code"], "name_ru": c["name_ru"],
                                       "aliases": sorted(a for a, target in aliases.items() if target == c["code"])}
                                      for c in self.matrix["classes"] if c["kind"] == "equipment"],
                "work_stages": [{"stage_id": s["id"], "name_ru": s["name_ru"], "stage_path": s["stage_path"],
                                 "stage_kind": s["stage_kind"], "object_type_codes": s["object_type_codes"]}
                                for s in self.matrix["stages"]]}

    def context(self, stage_ids, codes):
        unique = list(dict.fromkeys(stage_ids))
        selected = set(unique)
        candidates = []
        keys = ("stage_id", "source_number", "name_ru", "stage_path", "stage_kind", "review_status",
                "candidate_policy", "viewpoint", "photo_appearance", "close_view_details", "camera_appearance",
                "active_work_evidence", "temporal_changes", "result_only_warning", "visual_confusers",
                "exact_id_requirement", "cannot_determine_from_image", "questions_for_vlm", "catalog_notes",
                "exact_id_requires_external_context", "necessary_context_for_specific_claim")
        contexts = self.source_snapshot["tables"]["stage_class_context"]
        for stage_id in unique:
            profile = self.profiles[stage_id]
            item = {k: profile[k] for k in keys if k in profile}
            item["selectable_as_visual_work_candidate"] = profile["candidate_policy"] == "candidate"
            item["distinctions_within_shortlist"] = [c for c in profile["confusable_with"] if c["stage_id"] in selected]
            item["observed_equipment_context"] = [
                {"class_code": row["code"], "condition_ru": row["condition_ru"], "reason_ru": row["reason_ru"],
                 "decisive_alone": bool(row["decisive_alone"])}
                for row in contexts if row["stage_id"] == stage_id and row["code"] in codes]
            candidates.append(item)
        return {"role": "Reference descriptions, not observations or model predictions.",
                "guardrails": self.metadata["guardrails"],
                "selection_rules": ["Профиль не является наблюдением. Выбирать только конкретные пункты переданного плана.",
                                    "Сохранять визуально неразличимые альтернативы; одно фото не подтверждает начало/завершение."],
                "candidates": candidates}


class Storage:
    def __init__(self, settings, service=None):
        self.settings, self.service = settings, service

    @contextmanager
    def connection(self, *, admin=False):
        kwargs = dict(self.settings.database_kwargs)
        kwargs.update(connect_timeout=5, row_factory=dict_row)
        if self.settings.database_url:
            # The URI is secret process configuration, never formatted into errors.
            kwargs = {"conninfo": self.settings.database_url, "connect_timeout": 5, "row_factory": dict_row}
        with psycopg.connect(**kwargs) as connection:
            if self.service and not admin:
                connection.execute(sql.SQL("SET ROLE {}").format(sql.Identifier(ROLES[self.service])))
                connection.execute("SET statement_timeout = '15s'")
                connection.execute("SET lock_timeout = '5s'")
            yield connection

    def references(self):
        with self.connection() as connection:
            rule = connection.execute("SELECT * FROM analytics_catalog.rule_set WHERE version=%s", (self.settings.matrix_version,)).fetchone()
            if self.settings.profiles_version:
                profile_set = connection.execute("SELECT * FROM analytics_catalog.profile_set WHERE version=%s", (self.settings.profiles_version,)).fetchone()
            else:
                profile_set = connection.execute("SELECT * FROM analytics_catalog.profile_set ORDER BY imported_at DESC,version DESC LIMIT 1").fetchone()
            if not rule or not profile_set:
                raise AnalysisError("not_ready", "Versioned references have not been imported", 503, retryable=True)
            rows = connection.execute("SELECT stage_id,profile_json FROM analytics_catalog.visual_profile WHERE profile_set_version=%s ORDER BY stage_id", (profile_set["version"],)).fetchall()
        profiles = {row["stage_id"]: json.loads(row["profile_json"]) for row in rows}
        stage_ids = {s["id"] for s in rule["matrix_json"]["stages"]}
        if set(profiles) != stage_ids:
            raise AnalysisError("not_ready", "Profiles and catalogue identities disagree", 503, retryable=True)
        return References(rule["matrix_json"], rule["catalog_version"], profile_set["version"], profiles,
                          profile_set["source_snapshot"], profile_set["metadata_json"])

    @staticmethod
    def _identity(connection, table, keys, values, payload, code):
        fingerprint = digest(canonical(payload).encode("utf-8"))
        names = list(keys)
        columns = names + ["fingerprint", "payload"]
        connection.execute(sql.SQL("INSERT INTO analytics_runtime.{} ({}) VALUES ({}) ON CONFLICT DO NOTHING").format(
            sql.Identifier(table), sql.SQL(",").join(map(sql.Identifier, columns)),
            sql.SQL(",").join(sql.Placeholder() for _ in columns)), (*values, fingerprint, Jsonb(payload)))
        row = connection.execute(sql.SQL("SELECT fingerprint FROM analytics_runtime.{} WHERE {}").format(
            sql.Identifier(table), sql.SQL(" AND ").join(sql.SQL("{}=%s").format(sql.Identifier(k)) for k in names)), values).fetchone()
        if row["fingerprint"] != fingerprint:
            raise AnalysisError(code, "Immutable source identity has different content", 409)

    def _identities(self, connection, case):
        site, stream = case["site_id"], case["scope"]["plan_stream_code"] or ""
        frames = [case["frame"], *case["history"]["observations"]]
        for frame in frames:
            key = (site, frame["camera_id"], frame["image_id"])
            connection.execute("INSERT INTO analytics_runtime.frame_identity (site_id,camera_id,image_id,sha256,observed_at) VALUES (%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING",
                               (*key, frame["image_sha256"], moment(frame["observed_at"])))
            row = connection.execute("SELECT sha256,observed_at FROM analytics_runtime.frame_identity WHERE site_id=%s AND camera_id=%s AND image_id=%s", key).fetchone()
            if row["sha256"] != frame["image_sha256"] or row["observed_at"] != moment(frame["observed_at"]):
                raise AnalysisError("observation_identity_conflict", "Frame identity was reused with different bytes or time", 409)
        if case["plan"]:
            plan = case["plan"]
            self._identity(connection, "plan_snapshot", ("site_id", "stream_code", "plan_id", "revision_id"),
                           (site, stream, plan["plan_id"], plan["revision_id"]), plan, "plan_identity_conflict")
            for step in plan["steps"]:
                key = (site, stream, step["step_key"])
                connection.execute("INSERT INTO analytics_runtime.step_identity VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING", (*key, step["stage_id"]))
                row = connection.execute("SELECT stage_id FROM analytics_runtime.step_identity WHERE site_id=%s AND stream_code=%s AND step_key=%s", key).fetchone()
                if row["stage_id"] != step["stage_id"]:
                    raise AnalysisError("plan_identity_conflict", "A stable step key cannot change its catalogue work", 409)
        if case["schema_version"] == "frame-analysis-input-v2":
            resources = case["resource_plan"]
            if resources:
                self._identity(connection, "resource_plan_snapshot", ("site_id", "stream_code", "plan_id", "revision_id"),
                               (site, resources["plan_stream_code"] or "", resources["plan_id"], resources["revision_id"]),
                               resources, "resource_plan_identity_conflict")
            source = case["source_context"]
            self._identity(connection, "source_snapshot", ("site_id", "stream_code", "source_system", "snapshot_id"),
                           (site, stream, source["source_system"], source["source_snapshot_id"]),
                           {"source_context": source, "plan": case["plan"], "resource_plan": resources},
                           "source_snapshot_identity_conflict")
        history = case["history"]
        self._identity(connection, "history_snapshot", ("site_id", "stream_code", "snapshot_id"),
                       (site, stream, history["snapshot_id"]), history, "observation_identity_conflict")
        for event in history["progress_events"]:
            self._identity(connection, "progress_identity", ("site_id", "stream_code", "event_id"),
                           (site, stream, event["event_id"]), event, "plan_identity_conflict")

    def claim(self, case, metadata, image, fingerprint, versions):
        key = (self.service, case["site_id"], case["request_id"])
        with self.connection() as connection:
            # Transaction advisory lock serialises identical keys before identities/image work.
            lock_key = canonical(key)
            connection.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s,0))", (lock_key,))
            row = connection.execute("SELECT * FROM analytics_runtime.request WHERE service=%s AND site_id=%s AND request_id=%s FOR UPDATE", key).fetchone()
            if row:
                if row["fingerprint"] != fingerprint:
                    raise AnalysisError("idempotency_conflict", "Idempotency key was reused with different input", 409)
                return self._existing(connection, row)
            self._identities(connection, case)
            connection.execute("INSERT INTO analytics_runtime.image (sha256,data) VALUES (%s,%s) ON CONFLICT DO NOTHING", (case["frame"]["image_sha256"], image))
            analysis_id = str(uuid4())
            connection.execute("INSERT INTO analytics_runtime.request (service,site_id,request_id,analysis_id,fingerprint,state,metadata_text,image_sha256,versions,input_version) VALUES (%s,%s,%s,%s,%s,'running',%s,%s,%s,%s)",
                               (*key, analysis_id, fingerprint, metadata.decode("utf-8"), case["frame"]["image_sha256"], Jsonb(versions), case["schema_version"]))
            return {"new": True, "analysis_id": analysis_id}

    def _existing(self, connection, row):
        if row["state"] in {"succeeded", "failed"}:
            return {"new": False, "response": row["response"], "status": row["http_status"], "analysis_id": str(row["analysis_id"])}
        age = (datetime.now(timezone.utc) - row["updated_at"]).total_seconds()
        if row["state"] == "running" and age <= self.settings.execution_timeout:
            return {"new": False, "busy": True}
        if row["state"] != "unknown":
            connection.execute("UPDATE analytics_runtime.request SET state='unknown',updated_at=clock_timestamp() WHERE service=%s AND site_id=%s AND request_id=%s",
                               (row["service"], row["site_id"], row["request_id"]))
        return {"new": False, "unknown": True}

    def lookup(self, site, request_id, *, fingerprint=None, input_version=None):
        with self.connection() as connection:
            row = connection.execute("SELECT * FROM analytics_runtime.request WHERE service=%s AND site_id=%s AND request_id=%s FOR UPDATE", (self.service, site, request_id)).fetchone()
            if not row:
                raise AnalysisError("analysis_not_found", "Request is not present in the durable journal", 404)
            if input_version is not None and row["input_version"] != input_version:
                raise AnalysisError("analysis_not_found", "Request belongs to another API version", 404)
            if fingerprint is not None and row["fingerprint"] != fingerprint:
                raise AnalysisError("idempotency_conflict", "Idempotency key was reused with different input", 409)
            return self._existing(connection, row)

    def attempt(self, case, phase, payload):
        key = (self.service, case["site_id"], case["request_id"])
        with self.connection() as connection:
            connection.execute("INSERT INTO analytics_runtime.attempt (service,site_id,request_id,phase,payload) VALUES (%s,%s,%s,%s,%s)", (*key, phase, Jsonb(payload)))
            connection.execute("UPDATE analytics_runtime.request SET gateway_started=true,updated_at=clock_timestamp() WHERE service=%s AND site_id=%s AND request_id=%s", key)

    def finish(self, case, response, status, *, unknown=False):
        state = "unknown" if unknown else ("succeeded" if status == 200 else "failed")
        with self.connection() as connection:
            connection.execute("UPDATE analytics_runtime.request SET state=%s,response=%s,http_status=%s,updated_at=clock_timestamp() WHERE service=%s AND site_id=%s AND request_id=%s",
                               (state, Jsonb(response), status, self.service, case["site_id"], case["request_id"]))
