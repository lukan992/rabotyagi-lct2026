"""Pure deterministic analysis of the supplied, frozen plan/history snapshot."""
from __future__ import annotations

from datetime import timedelta

from .contracts import empty_transition, moment, result_envelope
from .equipment_activity import assess, ignored_idle_refs
from .ranking import rank
from .resource_plan import is_v2, temporal_reasons


def latest_progress(case):
    result = {}
    for index, event in enumerate(case["history"]["progress_events"]):
        key = (moment(event["effective_at"]), moment(event["recorded_at"]))
        previous = result.get(event["step_key"])
        if previous is None or key > previous[0]:
            result[event["step_key"]] = (key, event, "/history/progress_events/" + str(index))
    return result


def _classes(references, stage_id):
    return {p["class_code"] for p in references.matrix["pairs"]
            if p["stage_id"] == stage_id and p["kind"] == "equipment"}


def transition(case, references, *, excluded_detection_refs=None):
    excluded = excluded_detection_refs or set()
    value = empty_transition("no_published_plan")
    if temporal_reasons(case):
        return empty_transition("insufficient_evidence")
    if case["plan"] is None or case["scope"]["plan_stream_code"] is None:
        return value
    steps = sorted(case["plan"]["steps"], key=lambda s: s["sequence_no"])
    progress = latest_progress(case)
    anchored = [s for s in steps if s["step_key"] in progress and progress[s["step_key"]][1]["state"] in {"in_progress", "completed"}]
    if not anchored:
        value["status"] = "needs_progress_anchor"
        return value
    anchor = anchored[-1]
    value["current_step_key"] = anchor["step_key"]
    # A later sourced assertion does not supply completion of earlier no_class work.
    barriers = [s for s in steps if references.stages[s["stage_id"]]["stage_kind"] == "no_class"]
    blocking = next((s for s in barriers if s["sequence_no"] <= anchor["sequence_no"] and
                     (s["step_key"] not in progress or progress[s["step_key"]][1]["state"] != "completed")), None)
    if blocking:
        before = [s for s in anchored if s["sequence_no"] < blocking["sequence_no"]]
        value.update(status="not_distinguishable_by_equipment",
                     current_step_key=before[-1]["step_key"] if before else None,
                     next_step_key=blocking["step_key"])
        return value
    subsequent = [s for s in steps if s["sequence_no"] > anchor["sequence_no"]]
    if not subsequent:
        value["status"] = "no_next_stage"
        return value
    next_step = subsequent[0]
    value["next_step_key"] = next_step["step_key"]
    if references.stages[next_step["stage_id"]]["stage_kind"] == "no_class":
        value["status"] = "not_distinguishable_by_equipment"
        return value
    previous_visual = [s for s in steps if s["sequence_no"] <= anchor["sequence_no"] and
                       references.stages[s["stage_id"]]["stage_kind"] == "concrete"]
    prior_classes = _classes(references, previous_visual[-1]["stage_id"]) if previous_visual else set()
    distinctive = _classes(references, next_step["stage_id"]) - prior_classes
    value["distinctive_codes"] = sorted(distinctive)
    if not distinctive:
        value["status"] = "not_distinguishable_by_equipment"
        return value
    anchor_event = progress[anchor["step_key"]][1]
    events = [e for e in case["history"]["progress_events"] if e["step_key"] == anchor["step_key"]]
    reset = max((moment(e["effective_at"]) for e in events if e["state"] == "not_started"), default=None)
    starts = [moment(e["effective_at"]) for e in events if e["state"] == "in_progress" and (reset is None or moment(e["effective_at"]) > reset)]
    actual_start = anchor_event["actual_started_at"]
    anchored_at = moment(actual_start) if actual_start else min(starts, default=moment(anchor_event["effective_at"]))
    if references.stages[anchor["stage_id"]]["stage_kind"] == "no_class":
        anchored_at = moment(anchor_event["actual_completed_at"] or anchor_event["effective_at"])
    completed_barriers = [progress[s["step_key"]][1] for s in barriers if s["sequence_no"] < next_step["sequence_no"]]
    if completed_barriers:
        anchored_at = max(anchored_at, *(moment(e["actual_completed_at"] or e["effective_at"]) for e in completed_barriers))
    as_of = moment(case["history"]["as_of"])
    signal_start = max(anchored_at, as_of - timedelta(days=7))
    if not case["history"]["complete"] or moment(case["history"]["window_start"]) > signal_start:
        value["status"] = "history_incomplete"
        return value
    # One time point can have several camera views; it remains one temporal vote.
    points = {}
    usable = 0
    observations = [(case["frame"]["observed_at"], case["cv"], "/cv")]
    observations.extend((o["observed_at"], o["cv"], f"/history/observations/{i}/cv")
                        for i, o in enumerate(case["history"]["observations"]))
    for observed_at, cv, path in observations:
        time = moment(observed_at)
        if time < signal_start or cv["status"] != "ok":
            continue
        usable += 1
        evidence = [path + "/detections/" + str(i) for i, d in enumerate(cv["detections"])
                    if d["class_code"] in distinctive and path + "/detections/" + str(i) not in excluded]
        if evidence:
            points.setdefault(time, []).extend(evidence)
    value["supporting_observations"] = len(points)
    if points:
        times = sorted(points)
        value["evidence_first_at"] = times[0].isoformat()
        value["evidence_last_at"] = times[-1].isoformat()
        value["evidence_refs"] = [ref for time in times for ref in points[time]][:1000]
        value["status"] = "possible_start" if len(times) >= 2 and times[-1] - times[0] >= timedelta(minutes=15) else "single_or_short_signal"
    else:
        value["status"] = "no_signal" if usable else "cv_unavailable"
    return value


def schedule(case):
    if temporal_reasons(case):
        return {"status": "insufficient_evidence", "items": []}
    if not case["plan"] or case["scope"]["plan_stream_code"] is None:
        return {"status": "insufficient_evidence", "items": []}
    progress, as_of = latest_progress(case), moment(case["history"]["as_of"])
    items = []
    for step in sorted(case["plan"]["steps"], key=lambda s: s["sequence_no"]):
        deadline = moment(step["planned_end_at"])
        item = {"step_key": step["step_key"], "stage_id": step["stage_id"],
                "status": "insufficient_evidence", "reason_code": "no_sourced_progress",
                "overdue_seconds": None, "evidence_at": None, "evidence_refs": []}
        assertion = progress.get(step["step_key"])
        event = assertion[1] if assertion else None
        if event and event["actual_completed_at"]:
            completed = moment(event["actual_completed_at"])
            seconds = (completed - deadline).total_seconds()
            item.update(status="possible_delay" if seconds > 0 else "no_delay_indicated",
                        reason_code="actual_completion_after_deadline" if seconds > 0 else "completed_by_deadline",
                        overdue_seconds=max(0, seconds), evidence_at=event["actual_completed_at"], evidence_refs=[assertion[2]])
        elif event and event["state"] in {"not_started", "in_progress"} and moment(event["effective_at"]) > deadline:
            item.update(status="possible_delay", reason_code="open_state_after_deadline",
                        overdue_seconds=(moment(event["effective_at"]) - deadline).total_seconds(),
                        evidence_at=event["effective_at"], evidence_refs=[assertion[2]])
        elif deadline > as_of and (not is_v2(case) or event is not None):
            item.update(status="no_delay_indicated", reason_code="deadline_not_reached",
                        overdue_seconds=0, evidence_at=case["history"]["as_of"])
        elif event and event["state"] == "completed":
            item.update(reason_code="actual_completion_time_unknown", evidence_at=event["effective_at"], evidence_refs=[assertion[2]])
        items.append(item)
    statuses = {item["status"] for item in items}
    status = "possible_delay" if "possible_delay" in statuses else ("insufficient_evidence" if "insufficient_evidence" in statuses else "no_delay_indicated")
    return {"status": status, "items": items}


def analyze(case, references, analysis_id, input_sha, *, equipment_activity=None):
    result = result_envelope(case, "deterministic", analysis_id, input_sha, references)
    if equipment_activity is None and "equipment_activity" in case:
        equipment_activity = assess(case, result)
    excluded = ignored_idle_refs(case, equipment_activity)
    result["transition"] = transition(case, references, excluded_detection_refs=excluded)
    result["schedule"] = schedule(case)
    if not case["plan"] or case["scope"]["plan_stream_code"] is None:
        result["limitations"].append("Пункт плана не оценивается без плана и подтверждённой привязки участка.")
        return result
    if case["cv"]["status"] != "ok":
        result["limitations"].append("Фактический CV текущего кадра недоступен; отсутствие техники не установлено.")
    codes = [d["class_code"] for i, d in enumerate(case["cv"]["detections"])
             if f"/cv/detections/{i}" not in excluded]
    if excluded:
        result["limitations"].append("Машины с possible_idle и их неподвижная цепочка исключены из положительных CV-сигналов работы/перехода; это не подтверждает остановку или отставание работ.")
    ranking = rank(references.matrix, codes, case["object_type_code"])
    ordered = []
    steps = case["plan"]["steps"]
    nonvisual = [s for s in steps if references.stages[s["stage_id"]]["stage_kind"] == "no_class"]
    if nonvisual:
        result["limitations"].append("Пункты no_class не определяются по изображению или технике; их ход и сроки требуют внешних источников.")
    target = next((s for s in steps if s["step_key"] == result["transition"]["next_step_key"]), None)
    if target and references.stages[target["stage_id"]]["stage_kind"] == "no_class":
        result["limitations"].append(f"Последовательный переход заблокирован: завершение промежуточной no_class-работы {target['step_key']} не подтверждено действующим источником.")
    for candidate in ranking["candidates"]:
        for step in steps:
            if step["stage_id"] == candidate["stage_id"] and references.stages[step["stage_id"]]["stage_kind"] == "concrete":
                ordered.append({"step_key": step["step_key"], "stage_id": step["stage_id"],
                                "ranking": {k: candidate[k] for k in ("status", "signal_score", "role_score")} |
                                {"matches": [{k: p[k] for k in ("class_code", "role_weight", "signal_weight", "evidence_group")}
                                             for p in candidate["matches"]]}})
    if ordered:
        candidates = ordered[:10]
        used = {p["class_code"] for c in candidates for p in c["ranking"]["matches"]}
        evidence = [{"source": "cv_detection", "ref": f"/cv/detections/{i}", "role": "supports",
                     "explanation": "Класс техники технологически совместим с кандидатами; присутствие не подтверждает выполнение."}
                    for i, d in enumerate(case["cv"]["detections"])
                    if d["class_code"] in used and f"/cv/detections/{i}" not in excluded][:24]
        result["current_work"] = {"status": "assessed", "work_groups": [{
            "group_id": "scope-compatibility", "match_status": "specific" if len(candidates) == 1 else "ambiguous",
            "candidates": candidates, "visual_state": "not_evaluated", "area_bbox": case["scope"]["roi_bbox"],
            "evidence": evidence, "explanation": "Совместимость общего CV участка с планом; отдельные параллельные операции этим расчётом не локализованы."}]}
        if len(ordered) > 10:
            result["limitations"].append(f"Совместимы {len(ordered)} пунктов; показаны первые 10 по ранжированию, точный выбор не установлен.")
        result["limitations"].append("Баллы не являются вероятностями; условия технологии требуют предметной проверки.")
    elif codes and ranking["candidates"] and len(nonvisual) < len(steps):
        result["current_work"]["status"] = "outside_plan"
    if any(o["cv"]["status"] != "ok" for o in case["history"]["observations"]):
        result["limitations"].append("Часть исторических кадров не имеет доступного CV; это не отрицательное свидетельство работ.")
    if result["transition"]["status"] == "possible_start":
        result["limitations"].append("Повторное присутствие отличительной техники — возможное начало, не подтверждённое выполнение.")
    if any(item["status"] == "insufficient_evidence" for item in result["schedule"]["items"]):
        result["limitations"].append("Для части сроков нет достаточного подтверждённого хода; отсутствие машин не считается отставанием.")
    return result
