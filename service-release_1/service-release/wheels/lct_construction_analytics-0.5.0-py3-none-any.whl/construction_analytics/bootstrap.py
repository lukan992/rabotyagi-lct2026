"""Repeatable additive bootstrap and least-privilege application logins."""
from __future__ import annotations

import os
from dataclasses import replace

from psycopg import sql

from .import_references import import_references, migrate
from .storage import ROLES, Storage

LOGINS = {"deterministic": "lct_deterministic_app", "vlm_llm": "lct_vlm_app"}
PASSWORD_ENV = {"deterministic": "ANALYTICS_DETERMINISTIC_DB_PASSWORD",
                "vlm_llm": "ANALYTICS_VLM_DB_PASSWORD"}


def bootstrap(settings, matrix, profiles):
    passwords = {service: os.environ.get(variable, "") for service, variable in PASSWORD_ENV.items()}
    if not all(passwords.values()):
        raise ValueError("Both application database passwords are required")
    migrate(settings)
    imported = import_references(settings, matrix, profiles)
    with Storage(settings).connection(admin=True) as db:
        database = db.execute("SELECT current_database() AS name").fetchone()["name"]
        for service, login in LOGINS.items():
            existing = db.execute("SELECT rolsuper,rolcreatedb,rolcreaterole,rolreplication,rolbypassrls FROM pg_roles WHERE rolname=%s", (login,)).fetchone()
            if existing and any(existing.values()):
                raise ValueError("Existing application login has administrative privileges")
            memberships = db.execute("SELECT parent.rolname FROM pg_auth_members m JOIN pg_roles parent ON parent.oid=m.roleid JOIN pg_roles child ON child.oid=m.member WHERE child.rolname=%s", (login,)).fetchall()
            if any(row["rolname"] != ROLES[service] for row in memberships):
                raise ValueError("Existing application login has unexpected memberships")
            if not existing:
                db.execute(sql.SQL("CREATE ROLE {} LOGIN NOINHERIT").format(sql.Identifier(login)))
            db.execute(sql.SQL("ALTER ROLE {} LOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS PASSWORD {}").format(sql.Identifier(login), sql.Literal(passwords[service])))
            db.execute(sql.SQL("GRANT {} TO {}").format(sql.Identifier(ROLES[service]), sql.Identifier(login)))
            db.execute(sql.SQL("GRANT CONNECT ON DATABASE {} TO {}").format(sql.Identifier(database), sql.Identifier(login)))
    # Verify the actual LOGIN + SET ROLE path, not the administrator's access.
    import psycopg
    kwargs = psycopg.conninfo.conninfo_to_dict(settings.database_url) if settings.database_url else dict(settings.database_kwargs)
    for service, login in LOGINS.items():
        runtime = replace(settings, database_url="", database_kwargs={**kwargs, "user": login, "password": passwords[service]})
        refs = Storage(runtime, service).references()
        if refs.matrix["rule_version"] != settings.matrix_version or (settings.profiles_version and refs.profiles_version != settings.profiles_version):
            raise ValueError("Bootstrap reference versions disagree with release configuration")
    return {"status": "ready", "references": imported, "logins": LOGINS}
