"""Launch services or explicitly migrate/import their reference database."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import psycopg

from .import_references import import_references, migrate
from .settings import Settings, load_env


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--env-file", help="Explicit local environment file, never printed")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("migrate")
    importer = commands.add_parser("import-references")
    importer.add_argument("--matrix", required=True)
    importer.add_argument("--profiles", required=True)
    initializer = commands.add_parser("bootstrap")
    initializer.add_argument("--matrix", required=True)
    initializer.add_argument("--profiles", required=True)
    exporter = commands.add_parser("export-catalog")
    exporter.add_argument("--output", required=True)
    exporter.add_argument("--service", choices=("deterministic", "vlm_llm"), default="deterministic")
    server = commands.add_parser("serve")
    server.add_argument("--service", required=True, choices=("deterministic", "vlm_llm"))
    server.add_argument("--host", default="127.0.0.1")
    server.add_argument("--port", type=int, required=True)
    args = parser.parse_args()
    try:
        if args.env_file:
            load_env(args.env_file)
        settings = Settings.from_env()
        if args.command == "migrate":
            migrate(settings)
            print(json.dumps({"migration": "005_analytics_services", "status": "applied"}))
        elif args.command == "import-references":
            print(json.dumps(import_references(settings, args.matrix, args.profiles), ensure_ascii=False))
        elif args.command == "bootstrap":
            from .bootstrap import bootstrap
            print(json.dumps(bootstrap(settings, args.matrix, args.profiles), ensure_ascii=False))
        elif args.command == "export-catalog":
            from .contracts import structural
            from .storage import Storage
            catalog = Storage(settings, args.service).references().catalog()
            structural(catalog, "catalog")
            Path(args.output).write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            print(json.dumps({"status": "exported", "catalog_version": catalog["catalog_version"]}))
        else:
            import uvicorn
            from .api import create_app
            uvicorn.run(create_app(args.service, settings), host=args.host, port=args.port, log_level="warning")
    except psycopg.Error:
        parser.exit(2, "PostgreSQL operation failed; check local configuration and database privileges.\n")
    except (OSError, ValueError) as exc:
        parser.exit(2, type(exc).__name__ + ": configuration or source verification failed.\n")


if __name__ == "__main__":
    main()
