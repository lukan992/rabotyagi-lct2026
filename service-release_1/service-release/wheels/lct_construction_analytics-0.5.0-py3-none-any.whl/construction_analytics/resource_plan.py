"""Resource comparisons preserve provenance, missing values and camera coverage."""
from __future__ import annotations

import copy
import math
from collections import Counter, defaultdict

from .contracts import canonical, invalid, moment
from .errors import AnalysisError

RULE_VERSION = "resource-rules-v1"
LIMITS = {"resource_stages_max": 500, "resource_equipment_per_stage_max": 200,
          "resource_equipment_total_max": 10000, "manual_observation_items_max": 200,
          "resource_quantity_max": 1000000, "resource_source_ref_max_chars": 1000}


def is_v2(case):
    return case.get("schema_version") == "frame-analysis-input-v2"


def temporal_reasons(case):
    if not is_v2(case):
        return []
    reasons = []
    if case["analysis_mode"] == "demonstration":
        reasons.append("demonstration_mode")
    if case["source_context"]["data_type"] != "production":
        reasons.append("non_production_source")
    if case["source_context"]["timestamp_quality"] != "verified":
        reasons.append("timestamp_unverified")
    return reasons


def validate(case, references):
    if not is_v2(case):
        return
    source, observed, plan, target = (case[k] for k in (
        "source_context", "equipment_observation", "resource_plan", "resource_target"))
    def fail(path, message):
        invalid(path, message, "invalid_resource_context")
    if case["analysis_mode"] == "operational" and (
        source["data_type"] == "synthetic_demo" or source["timestamp_quality"] == "demonstration"
        or (observed["basis"] == "manual_visual_estimate" and observed["requires_validation"])
    ):
        invalid("/analysis_mode", "Demonstration data and unvalidated manual counts require demonstration mode", "data_mode_not_allowed")
    if moment(observed["observed_at"]) != moment(case["frame"]["observed_at"]):
        fail("/equipment_observation/observed_at", "Equipment observation must describe the current frame time")
    if case["cv"]["status"] == "ok" and observed["basis"] != "cv_detections":
        fail("/equipment_observation/basis", "Available real CV must be the sole resource counting basis")
    if observed["basis"] == "cv_detections":
        if case["cv"]["status"] != "ok" or observed["source_ref"] != case["cv"]["source_ref"]:
            fail("/equipment_observation", "CV counts require successful current CV and its source reference")
        identities = [(d["class_code"], tuple(d["bbox"])) for d in case["cv"]["detections"]]
        if len(set(identities)) != len(identities):
            fail("/cv/detections", "Identical class/bbox objects cannot count twice")

    def equipment(items, path):
        identities = set()
        for i, item in enumerate(items):
            here = f"{path}/{i}"
            if item["item_id"] in identities:
                fail(here + "/item_id", "Duplicate equipment item identity")
            identities.add(item["item_id"])
            if item["mapping_status"] == "mapped" and item["class_code"] not in references.equipment_codes:
                invalid(here + "/class_code", "Unknown canonical equipment class", "unknown_class")
    equipment(observed["items"], "/equipment_observation/items")
    if plan is None:
        return
    if plan["plan_stream_code"] is not None and plan["plan_stream_code"] != case["scope"]["plan_stream_code"]:
        fail("/resource_plan/plan_stream_code", "Resource and camera scope must identify the same stream")
    if sum(len(s["equipment"]) for s in plan["stages"]) > LIMITS["resource_equipment_total_max"]:
        invalid("/resource_plan/stages", "Resource equipment total exceeds the published limit", "payload_too_large", 413)
    steps = {s["step_key"]: s for s in case["plan"]["steps"]} if case["plan"] else {}
    codes, sequences, previous = set(), set(), None
    for index, stage in sorted(enumerate(plan["stages"]), key=lambda item: item[1]["sequence_no"]):
        path = f"/resource_plan/stages/{index}"
        if stage["stage_code"] in codes or stage["sequence_no"] in sequences:
            fail(path, "Resource stage codes and sequences must be unique")
        codes.add(stage["stage_code"]); sequences.add(stage["sequence_no"])
        start, end = moment(stage["planned_start_at"]), moment(stage["planned_end_at"])
        if start >= end or (previous is not None and start < previous):
            fail(path, "Resource stage dates must have positive durations and follow sequence")
        previous = start
        for key in stage["mapped_step_keys"]:
            step = steps.get(key)
            if step is None:
                fail(path + "/mapped_step_keys", "Mapped resource stages must reference the supplied detailed plan")
            if moment(step["planned_start_at"]) < start or moment(step["planned_end_at"]) > end:
                fail(path + "/mapped_step_keys", "Mapped work dates must lie within the source resource stage interval")
        for key in ("planned_volume", "planned_productivity"):
            if stage[key] is not None and not math.isfinite(stage[key]["value"]):
                fail(path + "/" + key, "Planned measurements must be finite")
        equipment(stage["equipment"], path + "/equipment")
    if target:
        stage = next((s for s in plan["stages"] if s["stage_code"] == target["stage_code"]), None)
        if stage is None:
            fail("/resource_target/stage_code", "Resource target does not exist in this plan")
        if target["selection_basis"] == "planned_at_frame_time":
            at = moment(case["frame"]["observed_at"])
            if not moment(stage["planned_start_at"]) <= at < moment(stage["planned_end_at"]):
                fail("/resource_target", "Planned-at-frame-time target must contain the frame time")


def assess(case, service):
    source, observed, plan, target = (case[k] for k in (
        "source_context", "equipment_observation", "resource_plan", "resource_target"))
    stage_index = next((i for i, s in enumerate(plan["stages"]) if target and s["stage_code"] == target["stage_code"]), None) if plan else None
    stage = plan["stages"][stage_index] if stage_index is not None else None
    value = {
        "status": "not_evaluated" if service == "vlm_llm" else "insufficient_evidence",
        "reason_codes": ["no_independent_measurements"],
        "stage_code": target["stage_code"] if target else None,
        "selection_basis": target["selection_basis"] if target else None,
        "basis": observed["basis"], "coverage": observed["coverage"], "equipment_items": [],
        "planned_volume": copy.deepcopy(stage["planned_volume"]) if stage else None,
        "planned_work_shifts": stage["planned_work_shifts"] if stage else None,
        "planned_productivity": copy.deepcopy(stage["planned_productivity"]) if stage else None,
        "actual_volume": None, "actual_productivity": None,
        "evidence_refs": ["/source_context", "/equipment_observation"],
        "limitations": [
            "Видимый счёт не устанавливает размер парка, дефицит техники или отставание.",
            "Фактический объём и производительность неизвестны без независимых измерений; плановые единицы сохранены без конверсии.",
        ],
    }
    if target:
        value["evidence_refs"].append("/resource_target")
    if stage:
        value["evidence_refs"].append(f"/resource_plan/stages/{stage_index}")
    if service == "vlm_llm":
        value["reason_codes"].append("vlm_resources_not_evaluated")
        value["limitations"].append("Числовое сравнение ресурсов выполняет только deterministic.")
        return value
    blocked = []
    if plan is None:
        blocked.append("no_resource_plan")
    if target is None:
        blocked.append("no_resource_target")
    if case["scope"]["plan_stream_code"] is None:
        blocked.append("scope_unknown")
    if plan and plan["plan_stream_code"] is None:
        blocked.append("resource_scope_unknown")
    if observed["coverage"] != "full_scope":
        blocked.append("partial_coverage" if observed["coverage"] == "partial_scope" else "unknown_coverage")
    if observed["basis"] == "unavailable":
        blocked.append("observation_unavailable")
    if case["analysis_mode"] == "operational":
        if source["data_type"] != "production":
            blocked.append("non_production_source")
        if source["timestamp_quality"] != "verified":
            blocked.append("timestamp_unverified")
        if observed["requires_validation"]:
            blocked.append("observation_requires_validation")
    else:
        value["reason_codes"].append("demonstration_mode")
        value["limitations"].append("Демонстрационные данные не используются для оперативных тревог и подтверждения хода работ.")
    value["reason_codes"].extend(blocked)
    counts, count_refs = {}, defaultdict(list)
    if observed["basis"] == "cv_detections" and case["cv"]["status"] == "ok":
        counts = Counter(d["class_code"] for d in case["cv"]["detections"])
        for i, detection in enumerate(case["cv"]["detections"]):
            count_refs[detection["class_code"]].append(f"/cv/detections/{i}")
    elif observed["basis"] == "manual_visual_estimate":
        for i, item in enumerate(observed["items"]):
            if item["class_code"] is not None:
                counts[item["class_code"]] = item["count"]
                count_refs[item["class_code"]].append(f"/equipment_observation/items/{i}")
            else:
                value["reason_codes"].append("observation_class_unmapped")
    if stage:
        planned_classes = Counter(item["class_code"] for item in stage["equipment"] if item["class_code"] is not None)
        if not stage["equipment"]:
            value["reason_codes"].append("no_planned_equipment")
        for i, item in enumerate(stage["equipment"]):
            code = item["class_code"]
            reasons = list(blocked)
            count = None
            if code is None:
                reasons.append("plan_class_unmapped")
            else:
                if planned_classes[code] > 1:
                    reasons.append("duplicate_planned_class")
                if observed["basis"] == "cv_detections" and case["cv"]["status"] == "ok":
                    count = counts[code]
                elif observed["basis"] == "manual_visual_estimate":
                    if len(count_refs[code]) > 1:
                        reasons.append("duplicate_observed_class")
                    elif code in counts:
                        count = counts[code]
                    else:
                        reasons.append("observation_class_missing")
            if item["planned_quantity"] is None:
                reasons.append("planned_quantity_unknown")
            delta = count - item["planned_quantity"] if not reasons and count is not None else None
            row = {"item_id": item["item_id"], "class_code": code, "planned_quantity": item["planned_quantity"],
                   "visible_count": count, "visible_count_delta": delta,
                   "status": "unknown" if delta is None else (
                       "visible_below_plan" if delta < 0 else "visible_above_plan" if delta > 0 else "visible_equal_plan"),
                   "reason_codes": list(dict.fromkeys(reasons)),
                   "evidence_refs": [f"/resource_plan/stages/{stage_index}/equipment/{i}", "/equipment_observation",
                                     *(count_refs[code] or (["/cv"] if observed["basis"] == "cv_detections" else []))]}
            value["equipment_items"].append(row)
            value["reason_codes"].extend(reasons)
    if case["analysis_mode"] == "demonstration":
        value["status"] = "demonstration"
    elif any(row["visible_count_delta"] is not None for row in value["equipment_items"]):
        value["status"] = "compared"
    value["reason_codes"] = list(dict.fromkeys(value["reason_codes"]))
    if blocked or any(row["status"] == "unknown" for row in value["equipment_items"]):
        value["limitations"].append("Неизвестные строки не сравниваются: причины приведены в reason_codes; отсутствие данных не заменено нулём.")
    return value


def validate_result(case, result):
    if not is_v2(case):
        return
    expected_version = RULE_VERSION if result["service"] == "deterministic" else None
    if (result["source_context"] != case["source_context"] or result["analysis_mode"] != case["analysis_mode"]
        or result["versions"]["resource_rules_version"] != expected_version
        or canonical(result["resource_assessment"]) != canonical(assess(case, result["service"]))):
        raise AnalysisError("internal_error", "Resource result does not preserve input provenance or comparison rules", 500, execution_state="failed")
