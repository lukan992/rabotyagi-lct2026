"""Read-only compatibility reader for the historical SQLite CLI."""
import json
import sqlite3
from pathlib import Path

def connect_readonly(path):
    return sqlite3.connect(Path(path).resolve().as_uri() + "?mode=ro", uri=True)

def candidate_context(db, stage_ids):
    unique = list(dict.fromkeys(stage_ids))
    if not unique:
        raise ValueError("At least one stage ID is required")
    profiles = []
    for stage_id in unique:
        row = db.execute("SELECT profile_json FROM visual_profile WHERE stage_id=?", (stage_id,)).fetchone()
        if row is None:
            raise ValueError(f"Unknown stage ID: {stage_id}")
        profiles.append(json.loads(row[0]))
    guardrails = json.loads(db.execute("SELECT value_json FROM metadata WHERE key='guardrails'").fetchone()[0])
    selected = set(unique)
    candidates = []
    keys = (
        "stage_id", "source_number", "name_ru", "stage_path", "stage_kind", "review_status",
        "candidate_policy", "viewpoint", "photo_appearance", "close_view_details", "camera_appearance",
        "active_work_evidence", "temporal_changes", "result_only_warning", "visual_confusers",
        "exact_id_requirement", "cannot_determine_from_image", "questions_for_vlm", "catalog_notes",
        "exact_id_requires_external_context", "necessary_context_for_specific_claim",
    )
    for p in profiles:
        item = {k: p[k] for k in keys if k in p}
        item["selectable_as_visual_work_candidate"] = p["candidate_policy"] == "candidate"
        item["distinctions_within_shortlist"] = [c for c in p["confusable_with"] if c["stage_id"] in selected]
        candidates.append(item)
    return {
        "schema_version": "visual-work-candidate-context-v1",
        "role": "Reference descriptions, not observations or model predictions.",
        "guardrails": guardrails,
        "selection_rules": [
            "Не выбирать сводную или организационную строку как визуально подтверждённую конкретную работу.",
            "Не считать порядок кандидатов доказательством и не выдумывать изображение по описанию.",
            "Если для точного ID нужен проектный тип, учётный признак или скрытая информация, сохранить альтернативы до получения этих данных.",
            "При отсутствии достаточных признаков вернуть insufficient_evidence; если список не подходит сцене, вернуть none_of_candidates.",
            "Указывать фактически видимый объект, действие и место в кадре; не использовать численную уверенность как откалиброванную вероятность.",
        ],
        "candidates": candidates,
    }

def search(db, query):
    needle = query.strip().casefold()
    if not needle:
        raise ValueError("Search text must not be empty")
    # SQLite's built-in NOCASE does not case-fold Cyrillic. 377 profiles are
    # small enough for deterministic Unicode-aware substring search in Python.
    result = []
    for row in db.execute("SELECT stage_id,profile_json FROM visual_profile ORDER BY stage_id"):
        p = json.loads(row[1])
        text = " ".join(p[k] for k in ("name_ru", "stage_path", "photo_appearance"))
        if needle in text.casefold():
            result.append({k: p[k] for k in ("stage_id", "name_ru", "viewpoint", "candidate_policy")})
    return result
