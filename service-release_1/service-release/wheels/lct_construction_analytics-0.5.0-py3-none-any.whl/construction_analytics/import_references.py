"""One-time, verified import. SQLite is a migration source, not service storage."""
from __future__ import annotations

import json
import sqlite3
from contextlib import closing
from importlib.resources import files
from pathlib import Path

from psycopg.types.json import Jsonb

from .contracts import canonical, digest
from .storage import Storage


def migrate(settings):
    with Storage(settings).connection(admin=True) as connection:
        for name in ("005_analytics_services.sql", "006_resource_plan.sql"):
            ddl = files("construction_analytics").joinpath("resources/" + name).read_text(encoding="utf-8")
            connection.execute(ddl)


def import_references(settings, matrix_path, sqlite_path):
    matrix_bytes, sqlite_bytes = Path(matrix_path).read_bytes(), Path(sqlite_path).read_bytes()
    matrix, matrix_sha, profile_sha = json.loads(matrix_bytes), digest(matrix_bytes), digest(sqlite_bytes)
    with closing(sqlite3.connect(Path(sqlite_path).resolve().as_uri() + "?mode=ro", uri=True)) as source:
        source.row_factory = sqlite3.Row
        if source.execute("PRAGMA integrity_check").fetchone()[0] != "ok" or source.execute("PRAGMA foreign_key_check").fetchall():
            raise ValueError("Source SQLite integrity check failed")
        tables = {}
        for row in source.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            name = row[0]
            # Identifiers come from the actual source schema, and are quoted.
            quoted = '"' + name.replace('"', '""') + '"'
            tables[name] = [dict(r) for r in source.execute("SELECT * FROM " + quoted)]
    profiles = {r["stage_id"]: r["profile_json"] for r in tables["visual_profile"]}
    stages = {s["id"]: s for s in matrix["stages"]}
    if len(stages) != 377 or len(matrix["classes"]) != 56 or len(matrix["pairs"]) != 2238 or set(profiles) != set(stages):
        raise ValueError("Reference identities/counts do not match the reviewed v2 artefacts")
    for sid, raw in profiles.items():
        profile = json.loads(raw)
        for key in ("name_ru", "stage_kind", "stage_path", "parent_stage_id", "phase_id"):
            if profile[key] != stages[sid][key]:
                raise ValueError("Matrix/profile content disagrees for stage " + str(sid))
    metadata = {r["key"]: json.loads(r["value_json"]) for r in tables["metadata"]}
    expected_matrix_hashes = [value for name, value in metadata["input_sha256"].items()
                              if name.replace("\\", "/").endswith("/matrix_v2.json")]
    if expected_matrix_hashes != [matrix_sha]:
        raise ValueError("Profiles were authored against a different matrix")
    version, profile_version = matrix["rule_version"], "visual-profiles-" + profile_sha[:24]
    catalog_version = "catalog-" + matrix_sha[:24]
    snapshot = {"tables": tables}
    with Storage(settings).connection(admin=True) as connection:
        connection.execute("INSERT INTO analytics_catalog.rule_set (version,source_sha256,catalog_version,matrix_json) VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING", (version, matrix_sha, catalog_version, Jsonb(matrix)))
        stored_rule = connection.execute("SELECT * FROM analytics_catalog.rule_set WHERE version=%s", (version,)).fetchone()
        if stored_rule["source_sha256"] != matrix_sha or canonical(stored_rule["matrix_json"]) != canonical(matrix):
            raise ValueError("Immutable matrix version already contains different data")
        connection.execute("INSERT INTO analytics_catalog.profile_set (version,source_sha256,metadata_json,source_snapshot) VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING", (profile_version, profile_sha, Jsonb(metadata), Jsonb(snapshot)))
        stored_set = connection.execute("SELECT * FROM analytics_catalog.profile_set WHERE version=%s", (profile_version,)).fetchone()
        if stored_set["source_sha256"] != profile_sha or canonical(stored_set["source_snapshot"]) != canonical(snapshot):
            raise ValueError("Profile source snapshot verification failed")
        with connection.cursor() as cursor:
            cursor.executemany("INSERT INTO analytics_catalog.visual_profile (profile_set_version,stage_id,profile_json) VALUES (%s,%s,%s) ON CONFLICT DO NOTHING", [(profile_version, sid, raw) for sid, raw in profiles.items()])
        rows = connection.execute("SELECT stage_id,profile_json FROM analytics_catalog.visual_profile WHERE profile_set_version=%s", (profile_version,)).fetchall()
        if {r["stage_id"]: r["profile_json"] for r in rows} != profiles:
            raise ValueError("PostgreSQL profile IDs/content do not exactly match SQLite")
    return {"catalog_version": catalog_version, "profiles_version": profile_version,
            "profiles": len(profiles), "matrix_pairs": len(matrix["pairs"]),
            "source_tables_preserved": len(tables), "verified": True}
