"""Standalone construction-context-v1 contract extracted from the tested benchmark."""
from __future__ import annotations
import json
import re
from typing import Any

SCHEMA_VERSION = "construction-context-v1"

ROOT_FIELDS = {
    "schema_version",
    "image_id",
    "status",
    "scene_summary",
    "image_quality",
    "observations",
    "relations",
    "checks",
    "activity_hypotheses",
    "limitations",
}

QUALITY_FIELDS = {"view", "detail", "occlusion", "issues"}

OBS_FIELDS = {
    "id",
    "category",
    "label",
    "description",
    "state",
    "certainty",
    "bbox",
    "visible_count",
}

REL_FIELDS = {"id", "subject_id", "predicate", "object_id", "certainty", "description"}

CHECK_FIELDS = {"target", "result", "evidence_ids", "reason"}

HYP_FIELDS = {"activity_code", "support", "evidence_ids", "explanation", "uncertainty"}

CHECK_TARGETS = {
    "piles",
    "people",
    "excavation",
    "rebar",
    "formwork",
    "structural_frame",
    "stockpiled_materials",
    "floor_work_area",
}

LABELS = {
    "structure": {"scaffold", "formwork", "wall", "beam", "slab", "column", "roof", "pile", "pile_head"},
    "material": {"rebar", "steel_pipe", "cement_bags", "brick", "concrete_block", "glass"},
    "terrain": {"graded_ground", "soil_pile", "excavation", "trench"},
    "person": {"person"},
    "equipment": {"equipment"},
    "other": {"other"},
}

ACTIVITIES = {
    "earthworks",
    "piling",
    "concrete_works",
    "structural_assembly",
    "masonry",
    "roofing",
    "facade_works",
    "interior_finishing",
    "floor_works",
    "landscaping",
    "material_handling",
}

def extract_prompt(requirements_text: str) -> str:
    match = re.search(
        r"(?ms)^## 4\. Контракт ответа\s*(.*?)^## 6\. Использование",
        requirements_text,
    )
    if not match:
        raise ValueError("Sections 4-5 were not found in the requirements file")
    return (
        "Ты анализируешь один кадр строительной площадки. "
        "Соблюдай контракт ниже буквально. Не используй имя файла как визуальное доказательство.\n\n"
        + "## Контракт и инструкция\n\n"
        + match.group(1).strip()
    )

def validate_payload(payload: Any, image_id: str) -> list[str]:
    errors: list[str] = []
    if not isinstance(payload, dict):
        return ["payload_not_object"]
    missing = ROOT_FIELDS - payload.keys()
    extra = payload.keys() - ROOT_FIELDS
    errors.extend(f"root_missing:{field}" for field in sorted(missing))
    errors.extend(f"root_extra:{field}" for field in sorted(extra))
    if payload.get("schema_version") != SCHEMA_VERSION:
        errors.append("schema_version")
    if payload.get("image_id") != image_id:
        errors.append("image_id")
    status = payload.get("status")
    if status not in {"ok", "partial", "unassessable"}:
        errors.append("status")
    if not isinstance(payload.get("scene_summary"), str) or len(payload.get("scene_summary", "")) > 500:
        errors.append("scene_summary")

    quality = payload.get("image_quality")
    if not isinstance(quality, dict):
        errors.append("image_quality_type")
    else:
        if set(quality) != QUALITY_FIELDS:
            errors.append("image_quality_fields")
        if quality.get("view") not in {"outdoor", "indoor", "mixed", "unknown"}:
            errors.append("image_quality_view")
        if quality.get("detail") not in {"adequate", "limited", "insufficient"}:
            errors.append("image_quality_detail")
        if quality.get("occlusion") not in {"low", "medium", "high", "unknown"}:
            errors.append("image_quality_occlusion")
        issues = quality.get("issues")
        allowed_issues = {"blur", "darkness", "glare", "low_resolution", "distant_objects", "occlusion", "cropped_scene", "other"}
        if not isinstance(issues, list) or len(issues) != len(set(issues)) or any(issue not in allowed_issues for issue in issues):
            errors.append("image_quality_issues")

    observations = payload.get("observations")
    observation_ids: set[str] = set()
    if not isinstance(observations, list) or len(observations) > 30:
        errors.append("observations_type_or_limit")
        observations = []
    for index, obs in enumerate(observations):
        prefix = f"observation[{index}]"
        if not isinstance(obs, dict) or set(obs) != OBS_FIELDS:
            errors.append(prefix + ":fields")
            continue
        obs_id = obs.get("id")
        if not isinstance(obs_id, str) or not obs_id or obs_id in observation_ids:
            errors.append(prefix + ":id")
        else:
            observation_ids.add(obs_id)
        category = obs.get("category")
        label = obs.get("label")
        if category not in LABELS or label not in LABELS.get(category, set()):
            errors.append(prefix + ":category_label")
        if not isinstance(obs.get("description"), str) or len(obs.get("description", "")) > 300:
            errors.append(prefix + ":description")
        if obs.get("state") not in {"installed", "stockpiled", "assembled", "scattered", "unknown", "not_applicable"}:
            errors.append(prefix + ":state")
        if obs.get("certainty") not in {"high", "medium", "low"}:
            errors.append(prefix + ":certainty")
        bbox = obs.get("bbox")
        if not (
            isinstance(bbox, list)
            and len(bbox) == 4
            and all(isinstance(value, (int, float)) and not isinstance(value, bool) and 0 <= value <= 1 for value in bbox)
            and bbox[0] < bbox[2]
            and bbox[1] < bbox[3]
        ):
            errors.append(prefix + ":bbox")
        count = obs.get("visible_count")
        if count is not None and (not isinstance(count, int) or isinstance(count, bool) or count < 1):
            errors.append(prefix + ":visible_count")

    relations = payload.get("relations")
    relation_ids: set[str] = set()
    if not isinstance(relations, list) or len(relations) > 20:
        errors.append("relations_type_or_limit")
        relations = []
    for index, rel in enumerate(relations):
        prefix = f"relation[{index}]"
        if not isinstance(rel, dict) or set(rel) != REL_FIELDS:
            errors.append(prefix + ":fields")
            continue
        rel_id = rel.get("id")
        if not isinstance(rel_id, str) or not rel_id or rel_id in relation_ids:
            errors.append(prefix + ":id")
        else:
            relation_ids.add(rel_id)
        subject, obj = rel.get("subject_id"), rel.get("object_id")
        if subject not in observation_ids or obj not in observation_ids or subject == obj:
            errors.append(prefix + ":references")
        if rel.get("predicate") not in {"inside", "on", "adjacent_to"}:
            errors.append(prefix + ":predicate")
        if rel.get("certainty") not in {"high", "medium", "low"}:
            errors.append(prefix + ":certainty")
        if not isinstance(rel.get("description"), str) or len(rel.get("description", "")) > 300:
            errors.append(prefix + ":description")

    checks = payload.get("checks")
    check_targets: list[str] = []
    if not isinstance(checks, list) or len(checks) != 8:
        errors.append("checks_count")
        checks = []
    for index, check in enumerate(checks):
        prefix = f"check[{index}]"
        if not isinstance(check, dict) or set(check) != CHECK_FIELDS:
            errors.append(prefix + ":fields")
            continue
        target = check.get("target")
        check_targets.append(target)
        if target not in CHECK_TARGETS:
            errors.append(prefix + ":target")
        result = check.get("result")
        if result not in {"present", "uncertain", "not_observed", "not_assessable"}:
            errors.append(prefix + ":result")
        evidence = check.get("evidence_ids")
        if not isinstance(evidence, list) or any(item not in observation_ids for item in evidence):
            errors.append(prefix + ":evidence")
            evidence = []
        if result in {"present", "uncertain"} and not evidence:
            errors.append(prefix + ":evidence_required")
        if result in {"not_observed", "not_assessable"} and evidence:
            errors.append(prefix + ":evidence_must_be_empty")
        if not isinstance(check.get("reason"), str) or len(check.get("reason", "")) > 300:
            errors.append(prefix + ":reason")
    if set(check_targets) != CHECK_TARGETS or len(check_targets) != len(set(check_targets)):
        errors.append("checks_targets")

    hypotheses = payload.get("activity_hypotheses")
    if not isinstance(hypotheses, list) or len(hypotheses) > 3:
        errors.append("activity_hypotheses_type_or_limit")
        hypotheses = []
    all_evidence_ids = observation_ids | relation_ids
    for index, hyp in enumerate(hypotheses):
        prefix = f"hypothesis[{index}]"
        if not isinstance(hyp, dict) or set(hyp) != HYP_FIELDS:
            errors.append(prefix + ":fields")
            continue
        if hyp.get("activity_code") not in ACTIVITIES:
            errors.append(prefix + ":activity_code")
        if hyp.get("support") not in {"strong", "moderate", "weak"}:
            errors.append(prefix + ":support")
        evidence = hyp.get("evidence_ids")
        if not isinstance(evidence, list) or not evidence or any(item not in all_evidence_ids for item in evidence):
            errors.append(prefix + ":evidence")
        if not isinstance(hyp.get("explanation"), str) or len(hyp.get("explanation", "")) > 400:
            errors.append(prefix + ":explanation")
        if not isinstance(hyp.get("uncertainty"), str) or not hyp.get("uncertainty") or len(hyp.get("uncertainty", "")) > 300:
            errors.append(prefix + ":uncertainty")

    limitations = payload.get("limitations")
    if not isinstance(limitations, list) or len(limitations) > 8 or any(not isinstance(item, str) or len(item) > 300 for item in limitations):
        errors.append("limitations")
        limitations = []
    if status == "unassessable":
        if observations or relations or hypotheses:
            errors.append("unassessable_nonempty_content")
        if any(check.get("result") != "not_assessable" for check in checks if isinstance(check, dict)):
            errors.append("unassessable_checks")
        if not limitations:
            errors.append("unassessable_limitations")
    if status in {"ok", "partial"} and not observations:
        errors.append("assessable_without_observations")
    if status == "partial" and not limitations:
        errors.append("partial_without_limitations")
    return errors

def parse_model_content(content: Any) -> tuple[Any | None, str | None, bool]:
    if not isinstance(content, str):
        return None, "content_not_string", False
    try:
        return json.loads(content), None, True
    except json.JSONDecodeError as exc:
        fenced = re.search(r"```(?:json)?\s*(\{.*\})\s*```", content, re.I | re.S)
        if fenced:
            try:
                return json.loads(fenced.group(1)), f"strict_json:{exc.msg};fenced_json_recovered", False
            except json.JSONDecodeError:
                pass
        first, last = content.find("{"), content.rfind("}")
        if 0 <= first < last:
            try:
                return json.loads(content[first : last + 1]), f"strict_json:{exc.msg};embedded_json_recovered", False
            except json.JSONDecodeError:
                pass
        return None, f"strict_json:{exc.msg}@{exc.pos}", False
