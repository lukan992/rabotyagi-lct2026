"""Public errors deliberately contain no raw transport exceptions."""

class AnalysisError(Exception):
    def __init__(self, code, message, status=422, *, details=None,
                 retryable=False, execution_state="not_started"):
        super().__init__(message)
        self.code, self.message, self.status = code, message, status
        self.details = details or []
        self.retryable, self.execution_state = retryable, execution_state

    def response(self, service, request_id, *, version=1):
        return {"schema_version": "frame-analysis-error-v" + str(version), "request_id": request_id,
                "service": service, "code": self.code, "message": self.message,
                "details": self.details, "retryable": self.retryable,
                "execution_state": self.execution_state}
