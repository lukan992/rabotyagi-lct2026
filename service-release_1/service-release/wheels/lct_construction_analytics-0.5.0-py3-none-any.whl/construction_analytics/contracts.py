"""Structural and semantic validation shared by both real services."""
from __future__ import annotations

import hashlib
import io
import json
import math
from datetime import datetime, timezone
from importlib.resources import files

from jsonschema import Draft202012Validator, FormatChecker
from PIL import Image, UnidentifiedImageError

from . import __version__
from .errors import AnalysisError

SCHEMA = json.loads(files("construction_analytics").joinpath("resources/frame-analysis-v1.schema.json").read_text(encoding="utf-8"))
SCHEMA_V2 = json.loads(files("construction_analytics").joinpath("resources/frame-analysis-v2.schema.json").read_text(encoding="utf-8"))
LIMITS = {"image_max_bytes": 25_000_000, "metadata_max_bytes": 1_000_000,
          "image_max_side": 8192, "image_max_pixels": 40_000_000,
          "detections_max": 200, "plan_steps_max": 500,
          "history_observations_max": 500, "progress_events_max": 1000,
          "model_context_max_chars": 120_000, "idempotency_retention_seconds": 604800}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def moment(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def pointer(parts):
    return "".join("/" + str(p).replace("~", "~0").replace("/", "~1") for p in parts)


def structural(value, kind, *, version=None):
    if version is None:
        version = 2 if isinstance(value, dict) and str(value.get("schema_version", "")).endswith("-v2") else 1
    definitions = SCHEMA_V2 if version == 2 else SCHEMA
    schema = {"$ref": "#/$defs/" + kind, "$defs": definitions["$defs"]}
    errors = list(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(value))
    if errors:
        details = [{"path": pointer(e.absolute_path), "code": "schema",
                    "message": "Value does not satisfy " + str(e.validator)} for e in errors[:100]]
        raise AnalysisError("invalid_context", "JSON does not satisfy the contract", details=details)


def invalid(path, message, code="invalid_context", status=422):
    raise AnalysisError(code, message, status, details=[{"path": path, "code": code, "message": message}])


def bbox(box, path):
    if not all(math.isfinite(x) for x in box) or box[0] >= box[2] or box[1] >= box[3]:
        invalid(path, "Bounding box must have positive finite area")


def inside(box, roi):
    x, y = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    return roi is None or (roi[0] <= x <= roi[2] and roi[1] <= y <= roi[3])


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def parse_metadata(raw):
    if len(raw) > LIMITS["metadata_max_bytes"]:
        raise AnalysisError("payload_too_large", "Metadata exceeds the byte limit", 413)
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=_object,
                          parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Non-finite JSON number")))
    except (ValueError, UnicodeError, RecursionError):
        raise AnalysisError("invalid_request", "Metadata must be unambiguous UTF-8 JSON", 400) from None


def validate_request(case, image, references, media_type=None):
    structural(case, "request")
    # IDs are opaque, but cannot contain padding or control characters.
    def ids(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if isinstance(item, str) and (key.endswith("_id") or key in {"request_id", "step_key", "stage_code", "source_system", "class_code", "catalog_version", "plan_stream_code"}):
                    if item != item.strip() or any(ord(c) < 32 for c in item):
                        invalid("", "Identifiers cannot contain padding or control characters")
                ids(item)
        elif isinstance(value, list):
            for item in value:
                ids(item)
    ids(case)
    if case["catalog_version"] != references.catalog_version:
        invalid("/catalog_version", "Catalogue version does not match this service", "catalog_version_mismatch", 409)
    frame, history, scope = case["frame"], case["history"], case["scope"]
    as_of, window = moment(history["as_of"]), moment(history["window_start"])
    if as_of != moment(frame["observed_at"]) or window > as_of:
        invalid("/history", "History boundary must equal the frame time and follow window_start")
    roi = scope["roi_bbox"]
    if roi is not None:
        bbox(roi, "/scope/roi_bbox")
    def check_cv(cv, path, current=False):
        seen, track_ids = set(), set()
        for index, detection in enumerate(cv["detections"]):
            here = path + "/detections/" + str(index)
            if detection["detection_id"] in seen:
                invalid(here, "Duplicate detection identity")
            seen.add(detection["detection_id"])
            track_id = detection.get("track_id")
            if track_id is not None:
                if track_id in track_ids:
                    invalid(here + "/track_id", "Duplicate tracking identity within a frame")
                track_ids.add(track_id)
            if detection["class_code"] not in references.equipment_codes:
                invalid(here + "/class_code", "Unknown canonical equipment class", "unknown_class")
            bbox(detection["bbox"], here + "/bbox")
            if current and not inside(detection["bbox"], roi):
                invalid(here + "/bbox", "Detection centre is outside the assigned ROI")
    check_cv(case["cv"], "/cv", True)
    seen = {(frame["camera_id"], frame["image_id"])}
    observations = set()
    for index, observation in enumerate(history["observations"]):
        path = "/history/observations/" + str(index)
        identity = (observation["camera_id"], observation["image_id"])
        if identity in seen or observation["observation_id"] in observations:
            invalid(path, "Duplicate historical or current frame identity")
        seen.add(identity); observations.add(observation["observation_id"])
        if not window <= moment(observation["observed_at"]) <= as_of:
            invalid(path + "/observed_at", "Observation is outside the history window")
        check_cv(observation["cv"], path + "/cv")
    from .equipment_activity import validate_options
    validate_options(case, references)
    plan = case["plan"]
    steps = {}
    if plan is not None:
        sequences, previous = set(), None
        for step in sorted(plan["steps"], key=lambda s: s["sequence_no"]):
            if step["step_key"] in steps or step["sequence_no"] in sequences:
                invalid("/plan/steps", "Plan keys and sequence numbers must be unique")
            stage = references.stages.get(step["stage_id"])
            if stage is None or stage["stage_kind"] not in {"concrete", "no_class"}:
                invalid("/plan/steps", "Plan must reference a concrete or no_class catalogue work", "unknown_stage")
            if case["object_type_code"] and case["object_type_code"] not in stage["object_type_codes"]:
                invalid("/plan/steps", "Work is incompatible with the supplied object type")
            start, end = moment(step["planned_start_at"]), moment(step["planned_end_at"])
            if end <= start or (previous is not None and start < previous):
                invalid("/plan/steps", "Plan dates must have positive durations and follow sequence")
            steps[step["step_key"]] = step; sequences.add(step["sequence_no"]); previous = start
    events, assertions = set(), {}
    for index, event in enumerate(history["progress_events"]):
        path = "/history/progress_events/" + str(index)
        if event["event_id"] in events:
            invalid(path, "Duplicate progress identity")
        events.add(event["event_id"])
        if event["step_key"] not in steps or steps[event["step_key"]]["stage_id"] != event["stage_id"]:
            invalid(path, "Progress does not identify a work in the supplied plan")
        effective, recorded = moment(event["effective_at"]), moment(event["recorded_at"])
        if effective > as_of or recorded > as_of:
            invalid(path, "Future progress cannot influence this assessment")
        if recorded < effective:
            invalid(path, "Progress cannot be recorded before its effective time")
        times = [moment(event[k]) if event[k] else None for k in ("actual_started_at", "actual_completed_at")]
        if any(t is not None and t > effective for t in times) or (all(t is not None for t in times) and times[1] < times[0]):
            invalid(path, "Actual progress times are inconsistent")
        assertion = (event["step_key"], effective, recorded)
        payload = (event["state"], event["actual_started_at"], event["actual_completed_at"])
        if assertion in assertions and assertions[assertion] != payload:
            invalid(path, "Conflicting assertions at the same time", "ambiguous_progress")
        assertions[assertion] = payload
    from .resource_plan import validate as validate_resources
    validate_resources(case, references)
    if len(image) > LIMITS["image_max_bytes"]:
        raise AnalysisError("payload_too_large", "Image exceeds the byte limit", 413)
    if digest(image) != frame["image_sha256"]:
        invalid("/frame/image_sha256", "Image hash does not match supplied bytes", "image_hash_mismatch")
    if media_type is not None and media_type != frame["media_type"]:
        invalid("/frame/media_type", "Multipart and metadata media types disagree", "unsupported_media_type", 415)
    try:
        with Image.open(io.BytesIO(image)) as picture:
            if picture.format not in {"PNG", "JPEG", "WEBP"}:
                invalid("/frame/media_type", "Unsupported image encoding", "unsupported_media_type", 415)
            actual_type = {"PNG": "image/png", "JPEG": "image/jpeg", "WEBP": "image/webp"}[picture.format]
            if actual_type != frame["media_type"] or picture.size != (frame["width"], frame["height"]):
                invalid("/frame", "Decoded image metadata disagrees with supplied frame", "invalid_image")
            if picture.width * picture.height > LIMITS["image_max_pixels"]:
                raise AnalysisError("payload_too_large", "Image pixel count exceeds the limit", 413)
            if getattr(picture, "n_frames", 1) != 1 or picture.getexif().get(274, 1) != 1:
                invalid("/frame", "A single frame with applied orientation is required", "invalid_image")
        # PNG EXIF/frame inspection may load pixels; verification requires a fresh decoder.
        with Image.open(io.BytesIO(image)) as picture:
            picture.verify()
        with Image.open(io.BytesIO(image)) as picture:
            picture.load()
    except (UnidentifiedImageError, OSError, SyntaxError, ValueError, RuntimeError, EOFError, Image.DecompressionBombError):
        invalid("/frame", "Image cannot be decoded safely", "invalid_image")


def resolve(document, path):
    value = document
    for token in path.split("/")[1:]:
        token = token.replace("~1", "/").replace("~0", "~")
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def visual_step_keys(case, references):
    stages = references.stages
    return [s["step_key"] for s in case["plan"]["steps"]
            if stages.get(s["stage_id"], {}).get("stage_kind") == "concrete"] if case["plan"] else []


def validate_result(result, case, references=None):
    try:
        structural(result, "result")
    except AnalysisError:
        if result.get("service") == "vlm_llm":
            raise AnalysisError("model_invalid_response", "Model result does not satisfy the output contract", 502, execution_state="failed") from None
        raise AnalysisError("internal_error", "Generated result does not satisfy the output contract", 500, execution_state="failed") from None
    from .equipment_activity import validate_assessment
    validate_assessment(case, result)
    from .work_progress import validate_summary
    validate_summary(case, result, references)
    from .resource_plan import validate_result as validate_resources_result
    validate_resources_result(case, result)
    steps = {s["step_key"]: s for s in case["plan"]["steps"]} if case["plan"] else {}
    selectable = set(visual_step_keys(case, references)) if references else set(steps)
    areas = []
    for group in result["current_work"]["work_groups"]:
        anchors = set()
        for candidate in group["candidates"]:
            if candidate["step_key"] not in selectable or steps[candidate["step_key"]]["stage_id"] != candidate["stage_id"]:
                raise AnalysisError("model_invalid_response", "Candidate does not match the input plan", 502, execution_state="failed")
        for evidence in group["evidence"]:
            source, path = evidence["source"], evidence["ref"]
            document = result if source.startswith("visual_") else case
            try:
                target = resolve(document, path)
                allowed = ((source == "cv_detection" and path.startswith(("/cv/detections/", "/history/observations/")) and "detection_id" in target)
                           or (source == "progress_event" and path.startswith("/history/progress_events/") and "event_id" in target)
                           or (source == "visual_observation" and path.startswith("/visual_observations/") and "bbox" in target)
                           or (source == "visual_relation" and path.startswith("/visual_relations/") and "subject_id" in target))
                if not allowed:
                    raise KeyError(path)
            except (KeyError, IndexError, TypeError, ValueError):
                raise AnalysisError("model_invalid_response", "Evidence reference is invalid", 502, execution_state="failed") from None
            if source == "visual_observation" and evidence["role"] == "supports" and target["certainty"] in {"medium", "high"}:
                if not inside(target["bbox"], case["scope"]["roi_bbox"]):
                    raise AnalysisError("model_invalid_response", "Visual support is outside the ROI", 502, execution_state="failed")
                anchors.add(target["id"])
        if result["service"] == "vlm_llm" and not anchors:
            raise AnalysisError("model_invalid_response", "Group has no direct visual support", 502, execution_state="failed")
        areas.append(anchors)
    if result["service"] == "vlm_llm":
        for index, area in enumerate(areas):
            other = set().union(*(a for j, a in enumerate(areas) if index != j))
            if not area - other:
                raise AnalysisError("model_invalid_response", "Work groups lack distinct visual anchors", 502, execution_state="failed")


def empty_transition(status="not_evaluated"):
    return {"status": status, "current_step_key": None, "next_step_key": None,
            "distinctive_codes": [], "evidence_first_at": None, "evidence_last_at": None,
            "supporting_observations": 0, "evidence_refs": []}


def result_envelope(case, service, analysis_id, input_sha, references):
    plan = case["plan"]
    status = "scope_unknown" if case["scope"]["plan_stream_code"] is None else ("no_plan" if plan is None else "insufficient_evidence")
    result = {"schema_version": "frame-analysis-result-v1", "request_id": case["request_id"],
            "analysis_id": analysis_id, "service": service,
            "context": {"site_id": case["site_id"], "camera_id": case["frame"]["camera_id"],
                        "image_id": case["frame"]["image_id"], "observed_at": case["frame"]["observed_at"],
                        "image_sha256": case["frame"]["image_sha256"], "plan_id": plan["plan_id"] if plan else None,
                        "plan_revision_id": plan["revision_id"] if plan else None,
                        "plan_stream_code": case["scope"]["plan_stream_code"],
                        "history_snapshot_id": case["history"]["snapshot_id"],
                        "catalog_version": references.catalog_version, "input_sha256": input_sha},
            "versions": {"service_version": __version__, "matrix_version": references.matrix["rule_version"] if service == "deterministic" else None,
                         "profiles_version": references.profiles_version if service == "vlm_llm" else None,
                         "vision_model": None, "llm_model": None,
                         "schedule_rules_version": "schedule-rules-v1" if service == "deterministic" else None},
            "current_work": {"status": status, "work_groups": []},
            "visual_observations": [], "visual_relations": [], "transition": empty_transition(),
            "schedule": {"status": "not_evaluated" if service == "vlm_llm" else "insufficient_evidence", "items": []},
            "limitations": []}
    from .resource_plan import RULE_VERSION, assess, is_v2, temporal_reasons
    if is_v2(case):
        result.update(schema_version="frame-analysis-result-v2", analysis_mode=case["analysis_mode"],
                      source_context=dict(case["source_context"]), resource_assessment=assess(case, service))
        result["versions"]["resource_rules_version"] = RULE_VERSION if service == "deterministic" else None
        if temporal_reasons(case):
            result["limitations"].append("Оперативные сроки и переходы не оцениваются: " + ", ".join(temporal_reasons(case)) + ".")
    return result
