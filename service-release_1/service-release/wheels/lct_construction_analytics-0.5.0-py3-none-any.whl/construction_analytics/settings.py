"""Process configuration; secrets are never included in representations."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from urllib.parse import urlparse


@dataclass(frozen=True)
class Settings:
    database_url: str = field(default="", repr=False)
    database_kwargs: dict = field(default_factory=dict, repr=False)
    service_token: str = field(default="", repr=False)
    gateway_key: str = field(default="", repr=False)
    gateway_url: str = "https://litellm.g-309.ru/v1"
    model: str = "qwen3.8-27b"
    max_concurrency: int = 1
    model_timeout: float = 240
    execution_timeout: int = 1020
    matrix_version: str = "construction-class-matrix-v2.0"
    profiles_version: str | None = None

    @classmethod
    def from_env(cls):
        kwargs = {"host": os.environ.get("POSTGRES_HOST", "127.0.0.1"),
                  "port": int(os.environ.get("POSTGRES_PORT", "5432")),
                  "dbname": os.environ.get("POSTGRES_DB", "construction_stages"),
                  "user": os.environ.get("POSTGRES_USER", "construction_app"),
                  "password": os.environ.get("POSTGRES_PASSWORD", "")}
        value = cls(database_url=os.environ.get("ANALYTICS_DATABASE_URL", ""), database_kwargs=kwargs,
                    service_token=os.environ.get("ANALYTICS_SERVICE_TOKEN", ""),
                    gateway_key=os.environ.get("LITELLM_API_KEY", ""),
                    gateway_url=os.environ.get("LITELLM_GATEWAY_URL", "https://litellm.g-309.ru/v1"),
                    model=os.environ.get("ANALYTICS_MODEL", "qwen3.8-27b"),
                    max_concurrency=int(os.environ.get("ANALYTICS_MAX_CONCURRENCY", "1")),
                    model_timeout=float(os.environ.get("ANALYTICS_MODEL_TIMEOUT_SECONDS", "240")),
                    execution_timeout=int(os.environ.get("ANALYTICS_EXECUTION_TIMEOUT_SECONDS", "1020")),
                    matrix_version=os.environ.get("ANALYTICS_MATRIX_VERSION", "construction-class-matrix-v2.0"),
                    profiles_version=os.environ.get("ANALYTICS_PROFILES_VERSION"))
        value.check()
        return value

    def check(self):
        if self.max_concurrency < 1 or self.model_timeout <= 0 or self.execution_timeout < 4 * self.model_timeout + 10:
            raise ValueError("Invalid concurrency or execution timeout configuration")
        url = urlparse(self.gateway_url)
        if url.scheme not in {"http", "https"} or not url.netloc or url.username or url.password:
            raise ValueError("Gateway must have an HTTP(S) base URL without embedded credentials")


def load_env(path):
    """Explicit local CLI option only; servers do not search for secret files."""
    from pathlib import Path
    for line in Path(path).read_text(encoding="utf-8-sig").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        if key.strip() not in os.environ:
            os.environ[key.strip()] = value.strip().strip("\"'")
