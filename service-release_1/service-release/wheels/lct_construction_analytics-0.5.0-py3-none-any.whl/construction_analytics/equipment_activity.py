"""Conservative per-detection activity assessment from a frozen camera history.

Geometry associations are hypotheses, not physical identities. A stationary
observation span never claims that nothing happened between sampled frames.
"""
from __future__ import annotations

import math
from copy import deepcopy

from .contracts import invalid, moment
from .errors import AnalysisError

RULE_VERSION = "bbox-equipment-activity-v1"
EXTENSION = "equipment-activity-v1"
DEFAULTS = {
    "idle_threshold_seconds": 14_400,
    "max_observation_gap_seconds": 1_800,
    "min_observations": 3,
    "min_detection_confidence": 0.5,
    "center_change_ratio": 0.1,
    "size_change_ratio": 0.2,
    "association_min_iou": 0.1,
    "association_max_center_shift_ratio": 1.5,
    "association_max_size_change_ratio": 0.6,
    "working_period": None,
    "class_idle_threshold_seconds": {},
}


def options(case):
    return {**deepcopy(DEFAULTS), **deepcopy(case["equipment_activity"])}


def validate_options(case, references):
    """Called after JSON Schema validation, before claiming any paid request."""
    if "equipment_activity" not in case:
        return
    config = options(case)
    classes = set(config["idle_candidate_classes"]) | set(config["class_idle_threshold_seconds"])
    if classes - references.equipment_codes:
        invalid("/equipment_activity", "Activity policy refers to an unknown equipment class", "unknown_class")
    period = config["working_period"]
    if period and moment(period["end_at"]) <= moment(period["start_at"]):
        invalid("/equipment_activity/working_period", "Working period must have a positive duration")
    # Two images from the same camera at one instant cannot be temporal votes.
    times = {(case["frame"]["camera_id"], moment(case["frame"]["observed_at"]))}
    for i, obs in enumerate(case["history"]["observations"]):
        key = (obs["camera_id"], moment(obs["observed_at"]))
        if key in times:
            invalid(f"/history/observations/{i}", "Activity history has duplicate camera/time observations")
        times.add(key)


def geometry(a, b):
    """Size-normalized centre displacement, relative size change and IoU."""
    aw, ah, bw, bh = a[2] - a[0], a[3] - a[1], b[2] - b[0], b[3] - b[1]
    centre = math.hypot(((a[0] + a[2]) - (b[0] + b[2])) / (2 * max((aw + bw) / 2, 1e-6)),
                        ((a[1] + a[3]) - (b[1] + b[3])) / (2 * max((ah + bh) / 2, 1e-6)))
    size = max(abs(aw - bw) / max(aw, bw, 1e-6), abs(ah - bh) / max(ah, bh, 1e-6))
    area = max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))
    union = aw * ah + bw * bh - area
    return centre, size, area / union if union > 0 else 0.0


def associate(newer, older, config):
    """Accept only mutual unique matches, including low-confidence competitors."""
    edges, reverse = {}, {}
    for i, new in enumerate(newer):
        candidates = []
        for j, old in enumerate(older):
            if new["class_code"] != old["class_code"]:
                continue
            new_id, old_id = new.get("track_id"), old.get("track_id")
            if new_id is not None or old_id is not None:
                compatible = new_id is not None and new_id == old_id
            else:
                centre, size, iou = geometry(new["bbox"], old["bbox"])
                compatible = (size <= config["association_max_size_change_ratio"]
                              and (iou >= config["association_min_iou"]
                                   or centre <= config["association_max_center_shift_ratio"]))
            if compatible:
                candidates.append(j)
                reverse.setdefault(j, []).append(i)
        edges[i] = candidates
    matches, reasons = {}, {}
    for i, candidates in edges.items():
        if len(candidates) == 1 and len(reverse[candidates[0]]) == 1:
            matches[i] = candidates[0]
        else:
            reasons[i] = "ambiguous_identity" if candidates else "identity_not_matched"
    return matches, reasons


def operation_refs(result, index):
    """Group evidence can veto an idle suspicion, not prove a machine is working."""
    path = f"/cv/detections/{index}"
    return [f"/current_work/work_groups/{i}" for i, group in enumerate(result["current_work"]["work_groups"])
            if group["visual_state"] == "operation_indicated"
            and any(e["source"] == "cv_detection" and e["ref"] == path and e["role"] == "supports"
                    for e in group["evidence"])]


def ignored_idle_refs(case, assessment):
    """Suppress only detections inside a currently suspected stationary suffix.

    Earlier movement, other cameras and other machines of the same class remain
    available. A geometric change boundary is not part of the idle interval.
    """
    if assessment is None:
        return set()
    times = {f"/cv/detections/{i}": moment(case["frame"]["observed_at"])
             for i in range(len(case["cv"]["detections"]))}
    for i, observation in enumerate(case["history"]["observations"]):
        times.update({f"/history/observations/{i}/cv/detections/{j}": moment(observation["observed_at"])
                      for j in range(len(observation["cv"]["detections"]))})
    return {path for item in assessment["items"] if item["status"] == "possible_idle"
            for path in item["evidence_refs"] if times[path] >= moment(item["stationary_since"])}


def _usable(detection, config):
    confidence = detection["confidence"]
    return confidence is not None and confidence >= config["min_detection_confidence"]


def assess(case, result):
    """Assess each currently visible detection; never merge different cameras."""
    config = options(case)
    now = moment(case["frame"]["observed_at"])
    camera = case["frame"]["camera_id"]
    period = config["working_period"]
    working = period is not None and moment(period["start_at"]) <= now < moment(period["end_at"])
    boundary = moment(period["start_at"]) if working else moment(case["history"]["window_start"])
    current = case["cv"]["detections"]
    tracks = []
    for index, detection in enumerate(current):
        reasons = []
        if not config["camera_stable"]:
            reasons.append("camera_not_stable")
        if not _usable(detection, config):
            reasons.append("current_detection_unreliable")
        tracks.append({"index": index, "last_index": index, "active": not reasons,
                       "reasons": reasons, "samples": [(now, detection, f"/cv/detections/{index}")],
                       "change": None, "centre": 0.0, "size": 0.0})
    past = sorted(((moment(o["observed_at"]), i, o) for i, o in enumerate(case["history"]["observations"])
                   if o["camera_id"] == camera), key=lambda item: item[0], reverse=True)
    newer, newer_time = current, now
    for time, index, obs in past:
        if not any(t["active"] for t in tracks):
            break
        stop = ("working_period_boundary" if time < boundary else
                "observation_gap" if (newer_time - time).total_seconds() > config["max_observation_gap_seconds"] else
                "historical_cv_unavailable" if obs["cv"]["status"] != "ok" else None)
        if stop:
            for track in tracks:
                if track["active"]:
                    track["reasons"].append(stop)
                    track["active"] = False
            break
        older = obs["cv"]["detections"]
        matches, reasons = associate(newer, older, config)
        for track in tracks:
            if not track["active"]:
                continue
            old_index = matches.get(track["last_index"])
            if old_index is None:
                track["reasons"].append(reasons[track["last_index"]])
                track["active"] = False
                continue
            detection = older[old_index]
            if not _usable(detection, config):
                track["reasons"].append("historical_detection_unreliable")
                track["active"] = False
                continue
            path = f"/history/observations/{index}/cv/detections/{old_index}"
            sample = (time, detection, path)
            # Compare to the current box, not just adjacent boxes: catch slow drift.
            centre, size, _ = geometry(current[track["index"]]["bbox"], detection["bbox"])
            track["centre"], track["size"] = max(track["centre"], centre), max(track["size"], size)
            if centre > config["center_change_ratio"] or size > config["size_change_ratio"]:
                track["change"] = sample
                track["active"] = False
            else:
                track["samples"].append(sample)
                track["last_index"] = old_index
        newer, newer_time = older, time
    items = []
    for track in tracks:
        index, samples = track["index"], track["samples"]
        detection = current[index]
        threshold = config["class_idle_threshold_seconds"].get(detection["class_code"], config["idle_threshold_seconds"])
        visual_refs = operation_refs(result, index)
        count = len(samples)
        span = (now - samples[-1][0]).total_seconds() if count >= 2 else 0.0
        reasons = list(track["reasons"])
        status = "unknown"
        if visual_refs and _usable(detection, config):
            status = "operation_indicated"
            reasons.insert(0, "operation_indicated_in_linked_group")
        elif not config["camera_stable"] or not _usable(detection, config):
            pass
        elif track["change"] and count == 1:
            status = "movement_indicated"
            reasons.insert(0, "bbox_change_above_tolerance")
        elif count >= 2:
            status = "stationary_observed"
            if count < config["min_observations"]:
                reasons.insert(0, "too_few_observations")
            elif span < threshold:
                reasons.insert(0, "stationary_span_below_threshold")
            elif not case["history"]["complete"]:
                reasons.insert(0, "history_incomplete")
            elif period is None:
                reasons.insert(0, "working_period_unknown")
            elif not working:
                reasons.insert(0, "outside_working_period")
            elif detection["class_code"] not in config["idle_candidate_classes"]:
                reasons.insert(0, "class_not_eligible_for_idle")
            else:
                status = "possible_idle"
                reasons.insert(0, "stationary_during_working_period")
        else:
            reasons.insert(0, "insufficient_matching_history")
        evidence = [s[2] for s in reversed(samples)]
        if track["change"]:
            evidence.insert(0, track["change"][2])
        limitations = ["Неизменность bbox на снимках не доказывает непрерывный простой между ними или отсутствие работы на месте."]
        if detection.get("track_id") is None:
            limitations.append("Сопоставление по геометрии — гипотеза идентичности; смена похожих машин в том же месте может остаться незаметной.")
        if visual_refs:
            limitations.append("VLM-признаки относятся к связанной группе работ и не подтверждают активность каждой машины.")
        items.append({"detection_id": detection["detection_id"], "class_code": detection["class_code"],
                      "track_id": detection.get("track_id"),
                      "association_method": "external_track_id" if detection.get("track_id") else "bbox_geometry",
                      "status": status, "reason_codes": list(dict.fromkeys(reasons)),
                      "observation_count": count + bool(track["change"]),
                      "stationary_observation_count": count if count >= 2 else 0,
                      "first_observed_at": (track["change"] or samples[-1])[0].isoformat(),
                      "last_observed_at": now.isoformat(),
                      "stationary_since": samples[-1][0].isoformat() if count >= 2 else None,
                      "stationary_observation_span_seconds": span,
                      "last_change_at": samples[-1][0].isoformat() if track["change"] else None,
                      "max_center_shift_ratio": track["centre"], "max_size_change_ratio": track["size"],
                      "idle_threshold_seconds": threshold, "evidence_refs": evidence,
                      "visual_activity_refs": visual_refs, "limitations": limitations})
    return {"schema_version": "equipment-activity-result-v1", "rules_version": RULE_VERSION,
            "camera_id": camera, "observed_at": now.isoformat(), "parameters": config,
            "status": "assessed" if any(i["status"] != "unknown" for i in items) else "insufficient_evidence",
            "reason_codes": ["current_cv_unavailable"] if case["cv"]["status"] != "ok" else
                            (["no_current_detections"] if not current else []),
            "items": items, "limitations": [
                "Ракурс объявляется стабильным источником; автоматическая компенсация движения камеры не выполняется.",
                "Оцениваются текущие видимые машины одной камеры; исчезновение из кадра не является простоем.",
                "possible_idle — подозрение по выбранной политике класса и рабочему периоду, а не подтверждённый простой.",
            ]}


def validate_assessment(case, result):
    """Check provenance and idle safeguards independently of the calculation."""
    enabled = "equipment_activity" in case
    if ("equipment_activity" in result) != enabled:
        raise AnalysisError("internal_error", "Activity extension presence disagrees with its request", 500)
    if not enabled:
        return
    assessment = result["equipment_activity"]
    config = options(case)
    frame, cv = case["frame"], case["cv"]
    now = moment(frame["observed_at"])
    valid = (assessment["rules_version"] == RULE_VERSION and assessment["camera_id"] == frame["camera_id"]
             and moment(assessment["observed_at"]) == now and assessment["parameters"] == config
             and result["versions"].get("equipment_activity_rules_version") == RULE_VERSION
             and len(assessment["items"]) == len(cv["detections"]))
    sources = {f"/cv/detections/{i}": (now, d) for i, d in enumerate(cv["detections"])}
    for i, obs in enumerate(case["history"]["observations"]):
        if obs["camera_id"] == frame["camera_id"] and obs["cv"]["status"] == "ok":
            sources.update({f"/history/observations/{i}/cv/detections/{j}": (moment(obs["observed_at"]), d)
                            for j, d in enumerate(obs["cv"]["detections"])})
    for i, item in enumerate(assessment["items"]):
        if i >= len(cv["detections"]):
            valid = False
            break
        detection = cv["detections"][i]
        threshold = config["class_idle_threshold_seconds"].get(detection["class_code"], config["idle_threshold_seconds"])
        paths = item["evidence_refs"]
        valid &= (item["detection_id"] == detection["detection_id"] and item["class_code"] == detection["class_code"]
                  and item["track_id"] == detection.get("track_id") and item["idle_threshold_seconds"] == threshold
                  and moment(item["last_observed_at"]) == now and f"/cv/detections/{i}" in paths
                  and len(paths) == len(set(paths)) == item["observation_count"]
                  and all(p in sources and sources[p][1]["class_code"] == detection["class_code"] for p in paths)
                  and item["visual_activity_refs"] == operation_refs(result, i))
        if item["stationary_since"] is not None:
            valid &= (now - moment(item["stationary_since"])).total_seconds() == item["stationary_observation_span_seconds"]
        else:
            valid &= item["stationary_observation_span_seconds"] == 0
        if item["status"] == "possible_idle":
            period = config["working_period"]
            valid &= bool(config["camera_stable"] and case["history"]["complete"] and period
                          and detection["class_code"] in config["idle_candidate_classes"]
                          and item["stationary_observation_count"] >= config["min_observations"]
                          and item["stationary_observation_span_seconds"] >= threshold
                          and not item["visual_activity_refs"])
            if period and item["stationary_since"] is not None:
                valid &= moment(period["start_at"]) <= moment(item["stationary_since"]) <= now < moment(period["end_at"])
            else:
                valid = False
    if not valid:
        raise AnalysisError("internal_error", "Activity assessment has invalid provenance or idle safeguards", 500)
