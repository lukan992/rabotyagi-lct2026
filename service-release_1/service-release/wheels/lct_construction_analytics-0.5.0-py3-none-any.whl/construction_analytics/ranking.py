"""Matrix-v2 evaluator; the algorithm is shared with the reference implementation."""
from __future__ import annotations
import json
from collections import defaultdict

def evidence_score(values, config):
    primary = sorted((x for x in values if x >= 2), reverse=True)[:config["max_primary_groups"]]
    return sum(primary) + min(config["context_cap"], config["context_increment"] * sum(x == 1 for x in values))

def rank(matrix, codes, object_type=None, phase_id=None, limit_groups=None):
    if not isinstance(codes, (list, tuple)) or any(not isinstance(c, str) or not c.strip() for c in codes):
        raise ValueError("codes must be a list of nonempty strings")
    class_map = {x["code"]: x for x in matrix["classes"]}
    normalized = sorted({matrix["aliases"].get(c.strip(), c.strip()) for c in codes})
    unknown = sorted(set(normalized) - class_map.keys())
    if unknown:
        raise ValueError("Unknown class codes: " + ", ".join(unknown))
    if object_type is not None and object_type not in {x["code"] for x in matrix["object_types"]}:
        raise ValueError("Unknown object_type")
    if limit_groups is not None and (type(limit_groups) is not int or limit_groups <= 0):
        raise ValueError("limit_groups must be a positive integer")
    phase_ids = {x["id"] for x in matrix["phases"]}
    if phase_id is not None and (type(phase_id) is not int or phase_id not in phase_ids):
        raise ValueError("Unknown phase_id")
    scope = None
    if phase_id is not None:
        scope = {phase_id}
        while True:
            expanded = scope | {p["id"] for p in matrix["phases"] if p["parent_id"] in scope}
            if expanded == scope:
                break
            scope = expanded
    stages = {s["id"]: s for s in matrix["stages"]}
    observed = set(normalized)
    by_stage = defaultdict(list)
    globally_mapped = {p["class_code"] for p in matrix["pairs"]}
    for p in matrix["pairs"]:
        s = stages[p["stage_id"]]
        if p["class_code"] not in observed or (scope is not None and s["phase_id"] not in scope):
            continue
        if object_type is not None and object_type not in s["object_type_codes"]:
            continue
        by_stage[s["id"]].append(p)
    candidates = []
    for sid, matches in by_stage.items():
        signals, roles = defaultdict(int), defaultdict(int)
        for p in matches:
            g = p["evidence_group"]
            signals[g] = max(signals[g], p["signal_weight"])
            roles[g] = max(roles[g], p["role_weight"])
        anchors = any(p["activity_anchor"] and p["signal_weight"] >= 2 for p in matches)
        primary_count = sum(s >= 2 for s in signals.values())
        status = "context_only" if not anchors else ("supported_candidate" if primary_count >= 2 else "single_signal")
        candidates.append({"stage_id": sid, "stage_name": stages[sid]["name_ru"], "phase_id": stages[sid]["phase_id"],
                           "signal_score": evidence_score(list(signals.values()), matrix["scoring"]),
                           "role_score": evidence_score(list(roles.values()), matrix["scoring"]), "status": status,
                           "matches": [{k: p[k] for k in ("class_code", "role_weight", "signal_weight", "relation_kind", "activity_anchor", "evidence_group")} for p in sorted(matches, key=lambda p: p["class_code"])]})
    order = {"supported_candidate": 2, "single_signal": 1, "context_only": 0}
    candidates.sort(key=lambda x: (-order[x["status"]], -x["signal_score"], -x["role_score"], x["stage_id"]))
    grouped = {}
    for c in candidates:
        signature = (c["status"], c["signal_score"], c["role_score"], json.dumps(c["matches"], sort_keys=True))
        if signature not in grouped:
            grouped[signature] = {"status": c["status"], "signal_score": c["signal_score"], "role_score": c["role_score"], "stage_ids": [], "matches": c["matches"]}
        grouped[signature]["stage_ids"].append(c["stage_id"])
    groups = list(grouped.values())
    leaders = {status: max((c["signal_score"] for c in candidates if c["status"] == status), default=0) for status in order}
    for g in groups:
        g["near_leader_within_status"] = leaders[g["status"]] - g["signal_score"] <= matrix["scoring"]["near_tie_delta"]
    rollup = []
    # 43 is not a peer competitor of its descendant phases: this entry contains
    # only the two works attached directly to 43, with that scope made explicit.
    for pid in sorted({c["phase_id"] for c in candidates}):
        best = next(c for c in candidates if c["phase_id"] == pid)
        rollup.append({"phase_id": pid, "scope": "direct_works_only" if pid == 43 else "phase_works", "best_stage_id": best["stage_id"],
                       "status": best["status"], "signal_score": best["signal_score"], "role_score": best["role_score"]})
    displayed = groups if limit_groups is None else groups[:limit_groups]
    return {"rule_version": matrix["rule_version"], "input_codes": normalized,
            "status": "insufficient_input" if not normalized else ("candidates" if candidates else "no_mapped_candidates_in_scope"),
            "known_but_unmapped": sorted(observed - globally_mapped),
            "candidates": candidates, "groups": displayed, "total_groups": len(groups), "has_more": len(displayed) < len(groups),
            "phase_rollup": rollup, "scores_are_probabilities": False}
